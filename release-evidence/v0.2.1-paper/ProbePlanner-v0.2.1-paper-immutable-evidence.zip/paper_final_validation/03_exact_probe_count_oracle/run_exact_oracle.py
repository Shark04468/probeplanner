#!/usr/bin/env python3
"""Independent exact minimum-probe oracle using a binary MILP."""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import statistics
import subprocess
import sys
import time
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix


HERE = Path(__file__).resolve().parent
CONFIG = json.loads((HERE / "CONFIG.json").read_text(encoding="utf-8"))
MODEL_DIR = HERE / "models"
CHECKPOINT = HERE / "oracle_checkpoint.json"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    low = int(position)
    high = min(len(ordered) - 1, low + 1)
    weight = position - low
    return ordered[low] * (1.0 - weight) + ordered[high] * weight


def git_value(source: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(source), *args], text=True, encoding="utf-8").strip()


def import_release_modules(source: Path) -> tuple[Any, Any]:
    script_dir = source / "apps" / "backend-compat" / "scripts"
    sys.path.insert(0, str(script_dir))
    import audit_registration_perturbation_sensitivity as atlas_util
    import benchmark_auto_probe_count_planning as bench

    return atlas_util, bench


def input_cases() -> list[dict[str, Any]]:
    locked_path = Path(CONFIG["lockedManifest"])
    actual_hash = sha256_path(locked_path)
    if actual_hash != CONFIG["lockedManifestSha256"]:
        raise RuntimeError(f"Locked manifest hash mismatch: {actual_hash}")
    locked = json.loads(locked_path.read_text(encoding="utf-8"))
    holdout = json.loads(Path(CONFIG["holdoutResults"]).read_text(encoding="utf-8"))
    rows: list[dict[str, Any]] = []
    for row in locked["cases"]:
        if row.get("status") != "ok" or row.get("uncoveredTargets") or row.get("uncoveredSides"):
            continue
        rows.append({
            "cohort": "locked27",
            "caseId": row["caseId"],
            "requestedTargets": row["requestedTargets"],
            "targetingMode": row["targetingMode"],
            "referenceSelectedCount": int(row["selectedProbeCount"]),
            "plannerRequest": row["plannerRequest"],
        })
    for row in holdout["cases"]:
        if row.get("coverageStatus") != "full":
            continue
        rows.append({
            "cohort": "untouched_holdout",
            "caseId": row["caseId"],
            "requestedTargets": row["requestedTargets"],
            "targetingMode": row["targetingMode"],
            "referenceSelectedCount": int(row["selectedProbeCount"]),
            "plannerRequest": row["plannerRequest"],
        })
    return rows


def build_exact_model(server: Any, candidates: list[dict[str, Any]], request: dict[str, Any]) -> dict[str, Any]:
    payload = server._normalize_optimize_payload(deepcopy(request))
    targets = list(payload["targetKeys"])
    mode = str(payload["params"].get("targetingMode", "single_hemisphere"))
    required = sorted(server._required_coverage_tokens(targets, mode))
    required_set = set(required)
    viable_candidates: list[dict[str, Any]] = []
    token_sets: list[set[str]] = []
    original_indices: list[int] = []
    for index, candidate in enumerate(candidates):
        tokens = set(server._candidate_coverage_tokens(candidate, targets, mode)) & required_set
        if not tokens:
            continue
        viable_candidates.append(candidate)
        token_sets.append(tokens)
        original_indices.append(index)

    min_clearance = float(payload["params"].get("minClearance", 1000.0))
    min_entry = float(payload["probeParams"].get("entrySpacingUm", 3500.0))
    conflicts: list[tuple[int, int]] = []
    for left in range(len(viable_candidates)):
        for right in range(left + 1, len(viable_candidates)):
            if server.trajs_collide(viable_candidates[left], viable_candidates[right], min_clearance, min_entry):
                conflicts.append((left, right))

    records = []
    for idx, (candidate, tokens, original_index) in enumerate(zip(viable_candidates, token_sets, original_indices)):
        records.append({
            "candidateIndex": idx,
            "pipelineCandidateIndex": original_index,
            "coverageTokens": sorted(tokens),
            "entryCcfUm": candidate.get("entry_xyz"),
            "tipCcfUm": candidate.get("tip_xyz"),
            "depthUm": candidate.get("depthUm_corrected", candidate.get("depthUm")),
            "thetaDeg": candidate.get("theta_deg"),
            "phiDeg": candidate.get("phi_deg"),
        })
    return {
        "requiredTokens": required,
        "candidateCount": len(viable_candidates),
        "pipelineCandidateCount": len(candidates),
        "candidates": records,
        "tokenSets": token_sets,
        "conflicts": conflicts,
    }


def solve_model(model: dict[str, Any]) -> dict[str, Any]:
    started = time.perf_counter()
    required = list(model["requiredTokens"])
    token_sets: list[set[str]] = model["tokenSets"]
    conflicts: list[tuple[int, int]] = model["conflicts"]
    candidate_count = int(model["candidateCount"])
    available = set().union(*token_sets) if token_sets else set()
    missing = sorted(set(required) - available)
    if missing:
        return {
            "solverStatus": "infeasible",
            "solverMessage": "candidate pool cannot cover required tokens",
            "exactMinimumCount": None,
            "incumbentCount": None,
            "selectedCandidateIndices": [],
            "optimalityGap": None,
            "timeout": False,
            "missingTokens": missing,
            "solverRuntimeSec": time.perf_counter() - started,
        }
    if not required:
        return {
            "solverStatus": "proven_optimal",
            "solverMessage": "empty coverage contract",
            "exactMinimumCount": 0,
            "incumbentCount": 0,
            "selectedCandidateIndices": [],
            "optimalityGap": 0.0,
            "timeout": False,
            "missingTokens": [],
            "solverRuntimeSec": time.perf_counter() - started,
        }

    row_indices: list[int] = []
    col_indices: list[int] = []
    data: list[float] = []
    lower: list[float] = []
    upper: list[float] = []
    row = 0
    for token in required:
        for index, tokens in enumerate(token_sets):
            if token in tokens:
                row_indices.append(row)
                col_indices.append(index)
                data.append(1.0)
        lower.append(1.0)
        upper.append(np.inf)
        row += 1
    for left, right in conflicts:
        row_indices.extend((row, row))
        col_indices.extend((left, right))
        data.extend((1.0, 1.0))
        lower.append(-np.inf)
        upper.append(1.0)
        row += 1
    matrix = coo_matrix((data, (row_indices, col_indices)), shape=(row, candidate_count)).tocsr()
    result = milp(
        c=np.ones(candidate_count, dtype=float),
        integrality=np.ones(candidate_count, dtype=np.uint8),
        bounds=Bounds(np.zeros(candidate_count), np.ones(candidate_count)),
        constraints=LinearConstraint(matrix, np.asarray(lower), np.asarray(upper)),
        options={
            "time_limit": float(CONFIG["solverTimeLimitSecPerCase"]),
            "mip_rel_gap": float(CONFIG["mipRelativeGap"]),
            "presolve": True,
            "disp": False,
        },
    )
    mapping = {0: "proven_optimal", 1: "feasible_not_proven_or_timeout", 2: "infeasible", 3: "unbounded", 4: "error"}
    status = mapping.get(int(result.status), "error")
    selected = [int(index) for index, value in enumerate(result.x)] if result.x is not None else []
    if result.x is not None:
        selected = [int(index) for index, value in enumerate(result.x) if float(value) > 0.5]
    incumbent = len(selected) if result.x is not None else None
    timeout = bool(int(result.status) == 1 and "time" in str(result.message).lower())
    return {
        "solverStatus": status,
        "solverMessage": str(result.message),
        "exactMinimumCount": incumbent if status == "proven_optimal" else None,
        "incumbentCount": incumbent,
        "selectedCandidateIndices": selected,
        "optimalityGap": float(result.mip_gap) if getattr(result, "mip_gap", None) is not None and math.isfinite(float(result.mip_gap)) else None,
        "timeout": timeout,
        "missingTokens": [],
        "solverRuntimeSec": time.perf_counter() - started,
        "highsStatusCode": int(result.status),
    }


def model_export(case_id: str, model: dict[str, Any]) -> tuple[str, str]:
    serializable = {
        "requiredTokens": model["requiredTokens"],
        "candidateCount": model["candidateCount"],
        "pipelineCandidateCount": model["pipelineCandidateCount"],
        "candidates": model["candidates"],
        "conflicts": [list(pair) for pair in model["conflicts"]],
    }
    data = (json.dumps(serializable, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    path = MODEL_DIR / f"{case_id}.exact_model.json.gz"
    with gzip.open(path, "wb", compresslevel=6) as handle:
        handle.write(data)
    return str(path), sha256_bytes(data)


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    certified = [row for row in rows if row["solverStatus"] == "proven_optimal"]
    runtimes = [float(row["solverRuntimeSec"]) for row in rows]
    cohorts = {}
    for cohort in sorted({str(row["cohort"]) for row in rows}):
        subset = [row for row in rows if row["cohort"] == cohort]
        cohort_certified = [row for row in subset if row["solverStatus"] == "proven_optimal"]
        cohorts[cohort] = {
            "caseCount": len(subset),
            "exactCertifiedCount": len(cohort_certified),
            "exactMatchCount": sum(1 for row in cohort_certified if row["exactMatchRerun"]),
            "referenceMatchCount": sum(1 for row in cohort_certified if row["exactMatchReference"]),
            "timeoutCount": sum(1 for row in subset if row["timeout"]),
            "infeasibleCount": sum(1 for row in subset if row["solverStatus"] == "infeasible"),
        }
    regimes: dict[str, dict[str, int]] = defaultdict(lambda: {"caseCount": 0, "certifiedCount": 0, "exactMatchCount": 0})
    for row in rows:
        key = str(row["probePlannerSelectedCount"])
        regimes[key]["caseCount"] += 1
        if row["solverStatus"] == "proven_optimal":
            regimes[key]["certifiedCount"] += 1
            regimes[key]["exactMatchCount"] += int(bool(row["exactMatchRerun"]))
    return {
        "totalCaseCount": len(rows),
        "exactCertifiedCaseCount": len(certified),
        "probePlannerExactMatchCount": sum(1 for row in certified if row["exactMatchRerun"]),
        "probePlannerExactMatchRateAmongCertified": sum(1 for row in certified if row["exactMatchRerun"]) / max(1, len(certified)),
        "referenceReplayCountMatch": sum(1 for row in rows if row["replayCountMatchesReference"]),
        "solverStatusCounts": dict(Counter(str(row["solverStatus"]) for row in rows)),
        "timeoutCount": sum(1 for row in rows if row["timeout"]),
        "byCohort": cohorts,
        "byProbeCountRegime": {key: regimes[key] for key in sorted(regimes, key=int)},
        "oracleRuntimeSec": {
            "median": statistics.median(runtimes) if runtimes else None,
            "p95": percentile(runtimes, 0.95),
            "max": max(runtimes) if runtimes else None,
        },
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "cohort", "caseId", "requestedTargets", "targetingMode", "candidatePoolSize",
        "referenceSelectedCount", "probePlannerSelectedCount", "exactOracleMinimumCount",
        "exactMatchRerun", "exactMatchReference", "replayCountMatchesReference", "solverStatus",
        "solverRuntimeSec", "pipelineRuntimeSec", "optimalityGap", "timeout", "conflictCount", "modelSha256",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(row.get(key)) if key == "requestedTargets" else row.get(key) for key in fields})


def main() -> int:
    source = Path(CONFIG["methodSource"])
    commit = git_value(source, "rev-parse", "HEAD")
    dirty = git_value(source, "status", "--porcelain")
    if commit != CONFIG["methodReleaseCommit"] or dirty:
        raise SystemExit("Exact oracle requires the clean locked method source")
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    cases = input_cases()
    atlas_util, _bench = import_release_modules(source)
    profile = Path(CONFIG["profileRoot"])
    atlas_util.configure_backend_environment(profile, workers=int(CONFIG["workers"]))
    server = atlas_util.import_backend_server()
    server.load_atlas()
    if not server.atlas_loaded:
        raise RuntimeError(f"Atlas failed to load: {server.atlas_error}")
    targets = sorted({target for row in cases for target in row["requestedTargets"]})
    ontology = atlas_util.apply_structure_tree_descendant_fallback(server, targets, atlas_util.DEFAULT_STRUCTURES_JSON)

    rows: list[dict[str, Any]] = []
    with server.app.app_context():
        for index, item in enumerate(cases, start=1):
            print(f"[oracle {index}/{len(cases)}] {item['cohort']} {item['caseId']}", flush=True)
            case_started = time.perf_counter()
            try:
                pipeline_started = time.perf_counter()
                pipeline = server._run_optimize_pipeline(deepcopy(item["plannerRequest"]))
                pipeline_runtime = time.perf_counter() - pipeline_started
                candidates = list(pipeline.get("candidatePreview") or [])
                selected = list(pipeline.get("selected") or [])
                model = build_exact_model(server, candidates, item["plannerRequest"])
                model_path, model_hash = model_export(item["caseId"], model)
                solved = solve_model(model)
                rerun_count = len(selected)
                exact_min = solved["exactMinimumCount"]
                row = {
                    **{key: item[key] for key in ("cohort", "caseId", "requestedTargets", "targetingMode", "referenceSelectedCount")},
                    "candidatePoolSize": model["candidateCount"],
                    "pipelineCandidatePoolSize": model["pipelineCandidateCount"],
                    "conflictCount": len(model["conflicts"]),
                    "probePlannerSelectedCount": rerun_count,
                    "exactOracleMinimumCount": exact_min,
                    "exactMatchRerun": solved["solverStatus"] == "proven_optimal" and exact_min == rerun_count,
                    "exactMatchReference": solved["solverStatus"] == "proven_optimal" and exact_min == item["referenceSelectedCount"],
                    "replayCountMatchesReference": rerun_count == item["referenceSelectedCount"],
                    "pipelineRuntimeSec": pipeline_runtime,
                    "modelPath": model_path,
                    "modelSha256": model_hash,
                    **solved,
                    "caseRuntimeSec": time.perf_counter() - case_started,
                }
            except Exception as exc:
                row = {
                    **{key: item[key] for key in ("cohort", "caseId", "requestedTargets", "targetingMode", "referenceSelectedCount")},
                    "candidatePoolSize": 0,
                    "pipelineCandidatePoolSize": 0,
                    "conflictCount": 0,
                    "probePlannerSelectedCount": 0,
                    "exactOracleMinimumCount": None,
                    "exactMatchRerun": False,
                    "exactMatchReference": False,
                    "replayCountMatchesReference": False,
                    "solverStatus": "error",
                    "solverMessage": f"{exc.__class__.__name__}: {exc}",
                    "solverRuntimeSec": 0.0,
                    "pipelineRuntimeSec": None,
                    "optimalityGap": None,
                    "timeout": False,
                    "caseRuntimeSec": time.perf_counter() - case_started,
                }
            rows.append(row)
            save(CHECKPOINT, {"completedCaseCount": len(rows), "totalCaseCount": len(cases), "cases": rows})

    summary = summarize(rows)
    payload = {
        "schemaVersion": "probeplanner.independent_exact_candidate_pool_oracle.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "methodReleaseCommit": commit,
        "profileRoot": str(profile),
        "solver": CONFIG["solver"],
        "solverTimeLimitSecPerCase": CONFIG["solverTimeLimitSecPerCase"],
        "claimScope": CONFIG["claimScope"],
        "ontologyFallback": deepcopy(ontology),
        "summary": summary,
        "cases": rows,
    }
    save(HERE / "exact_oracle_results.json", payload)
    save(HERE / "exact_oracle_summary.json", summary)
    write_csv(HERE / "exact_oracle_case_results.csv", rows)
    report = [
        "# Independent Exact Probe-count Oracle",
        "",
        f"- Solver: {CONFIG['solver']}",
        f"- Cases: {summary['totalCaseCount']}",
        f"- Proven optimal: {summary['exactCertifiedCaseCount']}",
        f"- ProbePlanner exact matches among certified cases: {summary['probePlannerExactMatchCount']}/{summary['exactCertifiedCaseCount']}",
        f"- Timeouts: {summary['timeoutCount']}",
        "",
        "The certificate applies only to the regenerated, strictly filtered candidate pool. It is not a continuous-space global optimum certificate.",
    ]
    (HERE / "REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
