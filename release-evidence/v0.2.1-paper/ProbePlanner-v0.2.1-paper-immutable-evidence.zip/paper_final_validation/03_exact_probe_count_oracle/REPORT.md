# Independent Exact Probe-count Oracle

- Solver: SciPy 1.15.3 milp / HiGHS binary MILP
- Cases: 48
- Proven optimal: 48
- ProbePlanner exact matches among certified cases: 47/48
- Timeouts: 0

The certificate applies only to the regenerated, strictly filtered candidate pool. It is not a continuous-space global optimum certificate.
