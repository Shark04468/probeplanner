# ProbePlanner Final Pre-submission Validation

This directory contains post-release validation only. It does not overwrite the
`v0.2.0-paper` method release, historical evidence, or Zenodo artifacts.

The validation contract is:

1. Prespecify case sets, perturbations, seeds, solver limits, data profiles, and
   acceptance semantics before running ProbePlanner.
2. Preserve full, partial, fail-closed, timeout, infeasible, and blocked results.
3. Report candidate-pool optimality only; never claim continuous-space global
   optimality.
4. Treat software validation separately from animal implantation accuracy,
   histological accuracy, and surgical safety.
5. Generate figures only from machine-readable experiment outputs.

Method release: `v0.2.0-paper` at
`0d5748e05c05e54d1330d05009747bcb4fa915a5`.

The active development worktree is dirty. Exact source hashes and the complete
dirty-file inventory are recorded in `PROVENANCE.md` and machine-readable run
metadata; no historical file is modified by this validation package.

## Final Verdict

**REQUIRES REVISION** for any claim of high-precision, subject-specific probe
planning or anatomical-boundary risk assessment.

| Experiment | Status | Main result |
| --- | --- | --- |
| 01 anatomical landmark TRE | BLOCKED | 0 eligible independent anatomical landmark pairs; minimum was 8 |
| 02 untouched holdout | MIXED | 21/26 full coverage; 3 partial; 2 fail closed |
| 03 exact candidate-pool oracle | STRENGTHENED WITH ONE MISMATCH | 47/48 exact probe-count matches; all 48 MILPs proven optimal |
| 04 native MRI containment | PARTIAL/FAIL | 15/57 straight native-MRI trajectories contained in an independent AMBMC mask |
| 05 clean reproduction | PARTIAL/TIMEOUT | 11/12 effective required checks passed; case 6 of the real-atlas benchmark timed out |
| 06 frozen stability holdout | FAIL GATE, STRONG STABILITY SIGNAL | 10/10 target sets and 200/200 rows complete; VISal case remained partial, while stabilized p95 entry/tip displacement was 0.075/0.0979 mm |

Read `FINAL_VALIDATION_SUMMARY.md` for claim-level interpretation and
`SHA256SUMS.txt` for the final artifact inventory.
