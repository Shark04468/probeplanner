# Provenance

## Method Source

- Public release tag: `v0.2.0-paper`.
- Release commit: `0d5748e05c05e54d1330d05009747bcb4fa915a5`.
- Clean detached worktree: `D:\probeplanner_final_validation\v0.2.0-paper-source`.
- Clean reproduction source: `D:\probeplanner_final_validation\clean-reproduction-20260816-local-archive\source`.
- Local git archive SHA256: `bab93de75e51f1e91f45d5c301fb468fdc4b13ef4a88672fda33d47abc72fce6`.
- The active development worktree was dirty and was not used as the method source for holdout, oracle, or frozen stability execution.

## Immutable Inputs

- Untouched holdout manifest SHA256: `25c177b405ecf395e86511e2150edef8bd7343a59e31497873b79705f39e5d55`.
- Frozen stability manifest SHA256: `e0920a3069fab018848f8d37da642e8c91cd562f7aaf6ef17c82e7b38d74952a`.
- Planning profile manifest SHA256: `ebaa6bade50c34f5d84fccd3092bef7dc904cada6e983f31af363ec61ada8222`.
- Historical clean locked benchmark manifest SHA256: `ae54b788825f758611bd6bf53953bbf9243bf45a7541c4866b4d9119c5df0181`.
- Historical locked benchmark result SHA256: `43ee59520dac6b45427a65d4098c24bf6edd6616d23dd3a1fdc9e1cb17c8499b`.
- Raw AMBMC MRI SHA256: `a433cde20e3972951eee50e29729df202c19b40a57decccaab02085d81831322`.
- Allen CCF average template SHA256: `e4a2b483e842b4c8c1b5452d940ea59e14bc1ebaa38fe6a9c3bacac6db2a8f4b`.
- Allen CCF annotation SHA256: `6f51f58b457e10c5889b5ce0df287ce82c3004d98f462a75d5c61705cd32d18d`.

## Public Release Defect

The public-tag copy at `supplementary-data/validation/final-benchmark/final-benchmark-manifest.json` has SHA256 `c4c162fd68ceb0fdfa58378ad4022027492fed2014bc2a3e7445b9da84843206`. All 32 case IDs contain a trailing newline. The historical clean locked manifest was used where a valid locked manifest was required. The public tag was not modified.

## Missing Historical Assets

- The exact locked `moving_brain_mask_full.nii.gz` is missing; only expected SHA256 `312636fb011e52599c966a3d269eef84724ee08bf5eb2d39b45470fbf509c426` remains.
- The locked planning profile's historical deformable field is missing at `D:\mri_ccf\planner_artifacts\mri_allen_bridge_v2_candidate_jacobian\registration\ambmc_to_ccf_displacement.nii.gz`.
- The available independent AMBMC mask has SHA256 `e65e6954d9502268bbbfe19ff28187f8e23ce0a650bf3b3a2b0486309154f7c0` and was not substituted as the locked mask.

## Preserved Corrections and Failures

- Clean reproduction: the original unsupported `--expected-shape` QC call and exit code 2 remain in `05_clean_reproduction/clean_reproduction_results.json`; the supported-CLI rerun is separate.
- Clean reproduction: two public clone transport failures and the 1800 s six-case timeout remain recorded.
- Stability: original three-case-parallel `h07` and `h09` outputs are retained with hashes in `06_stability_holdout/frozen_stability_summary.json`.
- Stability: serial reruns changed only resource scheduling, not targets, perturbations, weight, or planner parameters.
- Stability: original public-helper displacement fields remain in the CSV with a `released` prefix; independent rectangular matching is recorded separately.

## Integrity Scope

`SHA256SUMS.txt` binds every final validation artifact except itself. External raw data and large runtime caches are referenced by absolute path and input hash; they are not copied into this validation directory.
