# ProbePlanner Final Pre-submission Validation Summary

## Verdict

**REQUIRES REVISION**

The package strengthens the candidate-pool optimization and perturbation-stability evidence, but it does not validate high-precision subject-specific probe planning. The current evidence must not be presented as animal-specific anatomical accuracy or surgical safety.

## Experiment Outcomes

### 1. Independent anatomical landmark TRE

Status: **BLOCKED**.

No eligible independently annotated anatomical landmark pair exists locally (0/8 required minimum). The 75 regular-grid points, 256 automatic boundary points, and four low-confidence skull surrogates are not anatomical ground truth. Dice, HD95, Jacobian, and transform residuals cannot replace hold-out anatomical TRE.

### 2. Prespecified untouched holdout

Status: **COMPLETE WITH MIXED OUTCOMES**.

- 26 untouched target sets.
- 21 full coverage (80.77%), 3 partial (11.54%), and 2 fail closed (7.69%).
- All 21 full-coverage cases passed the strict trajectory audit.
- Median runtime 25.86 s; p95 65.80 s; maximum 76.56 s.

This supports reliable behavior on many cases, but not universal feasibility or coverage.

### 3. Exact probe-count oracle

Status: **COMPLETE, STRONG EVIDENCE WITH ONE MISMATCH**.

- 48/48 regenerated candidate-pool MILPs were proven optimal with zero reported MIP gap.
- ProbePlanner matched the exact minimum in 47/48 cases (97.92%).
- Locked cohort: 27/27 matches. Untouched full-coverage holdout: 20/21 matches.
- `holdout_015_bilateral_rsp_visp` used 4 probes while the exact candidate-pool optimum used 3.

The claim is minimum cardinality within the regenerated strict candidate pool, not continuous-space global optimality.

### 4. Native MRI containment

Status: **PARTIAL/FAIL FOR SUBJECT-SPECIFIC CLAIMS**.

- 57/57 locked trajectories were contained in their CCF planning representation.
- Only 15/57 (26.32%) straight physical trajectories were contained in the independent AMBMC native-MRI brain mask.
- Pointwise inverse-warp paths passed 11/57.
- Transform round-trip max error was 0.000814 mm, below one 0.015 mm native voxel.

The low containment is not a transform-inversion numerical error. It is a cross-profile audit using a population-average AMBMC atlas, not an individual animal. The locked planning transform and exact locked moving mask are unavailable, so the locked run cannot be replayed as a same-profile native containment experiment.

### 5. Clean-environment reproduction

Status: **PARTIAL/TIMEOUT**.

- Fresh public clone failed twice because the GitHub TLS connection reset; an exact local git archive of tag `v0.2.0-paper` was used on the same host.
- Release verification, JS/UI checks, locked Python installation, dependency check, backend tests, AllenSDK audit, and Rust tests passed.
- The original QC invocation contained an unsupported harness argument. A preserved post-hoc rerun with the public CLI passed Dice 0.84185, HD95 0.36572 mm, and manifest TRE 0.26708 mm.
- The six-case real-atlas benchmark completed cases 1-5, but case 6 did not finish within the prespecified 1800 s process timeout.

After correcting the harness-only error, 11/12 required checks passed. This is same-host reproducibility, not independent-machine reproduction.

### 6. Frozen stability holdout

Status: **FAIL BY PRESPECIFIED ZERO-FAILURE GATE, WITH STRONG STABILITY IMPROVEMENT**.

- Frozen `lambda=0.1`; 10/10 target sets complete; 200/200 non-identity method rows present.
- Stabilized within-method consistency: coverage 100%, probe count 100%, strict-audit failures 0.
- Stabilized entry/tip p95 displacement: 0.075/0.097892 mm; maxima 0.100/0.229357 mm.
- Stabilized entry/tip jumps above 1 mm: 0/0.
- Control entry/tip p95 displacement: 4.733/5.271 mm; 11/14 jumps above 1 mm.
- Median stabilized runtime overhead: 0.565 s; p95 overhead: 10.222 s.
- All 10 remaining non-ok stabilized rows belong to `stability_h04`: `VISp,VISpm,VISal` could not cover VISal even at identity.
- Relative to the control identity anchor, the stabilized method used a different probe count in 20 rows because `h05` and `h06` changed from two control probes to one stabilized probe while retaining coverage. Relative to each stabilized identity baseline, probe-count consistency was 100%.

Two parallel-run `MemoryError` artifacts (`h07`, `h09`) were preserved and rerun serially with unchanged algorithm settings; both serial reruns completed 11/11. The primary displacement summary uses an independent rectangular Hungarian assignment because the public helper does not optimize over subsets of both probe sets when counts differ. Original outputs remain preserved.

## Submission Claims

Claims currently supported:

- High exact-match rate for minimum probe count within the regenerated strict candidate pool.
- Strong reduction of trajectory sensitivity under the frozen reference-aware tie-breaker on feasible holdout target sets.
- Strict auditing and fail-closed behavior are observable and machine-readable.

Claims not supported:

- Subject-specific anatomical TRE or sub-0.3 mm targeting accuracy.
- Subject-specific skull/bregma/lambda localization.
- Native-space safety for an individual animal.
- Universal target-set feasibility.
- Independent-machine or fully successful end-to-end reproduction.
- Continuous-space global probe-count optimality.

## Required Revision

1. Acquire or license paired subject MRI/skull data with independently annotated anatomical and stereotaxic landmarks; report hold-out TRE and rater reliability.
2. Rebuild a single-profile native planning package in which the exact moving mask, forward/inverse transforms, labels, landmarks, Jacobian, and stats are all hash-bound and retained.
3. Resolve the `VISal` feasibility failure without changing the frozen holdout retrospectively; report the old failure and test the revised method on a new holdout.
4. Add an explicit time budget or progress checkpoint inside the real-atlas benchmark so one difficult case cannot consume the entire process timeout without case-level output.
5. Fix the public-tag benchmark manifest whose 32/32 case IDs contain trailing newlines, then create a new release instead of altering `v0.2.0-paper`.
6. Repeat clean reproduction on an independent machine and retain a successful public-network clone log.
