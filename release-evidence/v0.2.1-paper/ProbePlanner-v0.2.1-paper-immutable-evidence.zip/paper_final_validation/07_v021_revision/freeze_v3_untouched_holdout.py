#!/usr/bin/env python3
"""Freeze the post-remediation v3 untouched holdout with a new target roster."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import freeze_new_untouched_holdout as base


HERE = Path(__file__).resolve().parent
MANIFEST_PATH = HERE / "v021_v3_untouched_holdout_manifest.json"
LOCK_PATH = HERE / "v021_v3_untouched_holdout_lock.json"
SHA_PATH = HERE / "v021_v3_untouched_holdout_manifest.sha256"
V2_LOCK_PATH = HERE / "v021_untouched_holdout_lock.json"
AUDP_SMOKE_PATH = HERE / "audp_parent_fallback_smoke.json"
TEST_FILE = base.ROOT / "apps" / "backend-compat" / "tests" / "test_validation_scripts.py"


CASES = [
    base.case("v021_v3_001_single_aid", "single", ["AId"]),
    base.case("v021_v3_002_single_audv", "single", ["AUDv"]),
    base.case("v021_v3_003_single_visrl", "single", ["VISrl"]),
    base.case("v021_v3_004_single_cea", "single", ["CEA"]),
    base.case("v021_v3_005_single_po", "single", ["PO"]),
    base.case("v021_v3_006_single_pvt", "single", ["PVT"]),
    base.case("v021_v3_007_single_pvh", "single", ["PVH"]),
    base.case("v021_v3_008_single_snr", "single", ["SNr"]),
    base.case("v021_v3_009_nearby_association", "nearby_multi", ["AUDv", "PTLp", "VISrl"]),
    base.case("v021_v3_010_nearby_amygdala", "nearby_multi", ["CEA", "BMA"]),
    base.case("v021_v3_011_nearby_thalamic", "nearby_multi", ["PO", "CM", "RE"]),
    base.case("v021_v3_012_nearby_hypothalamic", "nearby_multi", ["PVH", "LHA", "ARH"]),
    base.case("v021_v3_013_distributed_aid_pvt", "distributed", ["AId", "PVT"]),
    base.case("v021_v3_014_distributed_sspbfd_po", "distributed", ["SSp-bfd", "PO"]),
    base.case("v021_v3_015_distributed_gu_cea", "distributed", ["GU", "CEA"]),
    base.case("v021_v3_016_distributed_ot_snr", "distributed", ["OT", "SNr"]),
    base.case("v021_v3_017_bilateral_audv_cm", "bilateral", ["AUDv", "CM"], "bilateral_symmetric"),
    base.case("v021_v3_018_bilateral_visrl_re", "bilateral", ["VISrl", "RE"], "bilateral_symmetric"),
    base.case("v021_v3_019_bilateral_bma_pvt", "bilateral", ["BMA", "PVT"], "bilateral_symmetric"),
    base.case("v021_v3_020_bilateral_cla_po", "bilateral", ["CLA", "PO"], "bilateral_symmetric"),
    base.case("v021_v3_021_quartet_cortex_thalamus", "high_order", ["AId", "AUDv", "PO", "PVT"]),
    base.case("v021_v3_022_quartet_visual_amygdala", "high_order", ["VISrl", "PTLp", "CEA", "BMA"]),
    base.case("v021_v3_023_quintet_distributed", "high_order", ["GU", "SSp-bfd", "CM", "RE", "SNr"]),
    base.case("v021_v3_024_fail_closed_shallow_snr", "negative_control", ["SNr"], depth_um=1500.0, max_angle_deg=5.0, expect_fail_closed=True),
    base.case("v021_v3_025_fail_closed_shallow_arh", "negative_control", ["ARH"], depth_um=1800.0, max_angle_deg=5.0, expect_fail_closed=True),
]


def main() -> int:
    if MANIFEST_PATH.exists() or LOCK_PATH.exists() or SHA_PATH.exists():
        raise SystemExit("v3 holdout is already frozen; refusing to overwrite lock artifacts")
    region_map = json.loads(base.REGION_MAP.read_text(encoding="utf-8"))
    ids = {str(row["canonicalAcronym"]): int(row["id"]) for row in region_map["entries"]}
    case_ids = [row["caseId"] for row in CASES]
    if len(case_ids) != len(set(case_ids)):
        raise RuntimeError("Duplicate v3 holdout case ID")
    missing = sorted({target for row in CASES for target in row["requestedTargets"] if target not in ids})
    if missing:
        raise RuntimeError(f"Targets missing from bound region map: {missing}")
    v2_lock = json.loads(V2_LOCK_PATH.read_text(encoding="utf-8"))
    frozen_at = datetime.now(timezone.utc).isoformat()
    manifest = {
        "schemaVersion": "probeplanner.prespecified_untouched_holdout.v3",
        "createdAt": frozen_at,
        "label": "v0.2.1 post-remediation planner-blind untouched holdout benchmark",
        "outcomeState": "unobserved_at_lock",
        "supersedesManifestSha256": v2_lock["manifestSha256"],
        "supersessionReason": "v2 first execution exposed missing parent-region provisioning; v3 binds the remediated source and uses a non-overlapping target roster",
        "caseSelection": "anatomically stratified fixed roster selected without invoking candidate generation, scoring, or optimization",
        "methodSnapshot": {
            "gitHead": base.git_value("rev-parse", "HEAD"),
            "gitDirty": bool(base.git_value("status", "--porcelain")),
            "sourceFiles": {
                str(path.relative_to(base.ROOT)).replace("\\", "/"): base.sha256(path)
                for path in (*base.SOURCE_FILES, TEST_FILE)
            },
        },
        "remediationEvidence": {
            "parentFallbackSmokeSha256": base.sha256(AUDP_SMOKE_PATH),
            "backendTestCommand": "python -m pytest apps/backend-compat/tests -q",
            "backendTestResult": "103 passed",
        },
        "profileRoot": str(base.PROFILE_ROOT.resolve()),
        "profileManifestSha256": base.sha256(base.PROFILE_MANIFEST),
        "regionMapV2Sha256": base.sha256(base.REGION_MAP),
        "plannerInvokedDuringSelection": False,
        "candidateOutcomesObservedDuringSelection": False,
        "caseCount": len(CASES),
        "acceptanceGates": {
            "allCasesRetained": True,
            "noExecutionErrors": True,
            "fullCasesRequireIndependentStrictAudit": True,
            "negativeControlsMustFailClosed": True,
            "exactOracleRequiredForAllFullCases": True,
            "noOracleTimeouts": True,
        },
        "cases": [
            {
                **row,
                "targetStructureIds": [ids[target] for target in row["requestedTargets"]],
            }
            for row in CASES
        ],
    }
    base.save(MANIFEST_PATH, manifest)
    manifest_hash = base.sha256(MANIFEST_PATH)
    lock = {
        "schemaVersion": "probeplanner.untouched_holdout.lock.v1",
        "lockedAt": frozen_at,
        "status": "LOCKED_UNEXECUTED",
        "manifestPath": str(MANIFEST_PATH.resolve()),
        "manifestSha256": manifest_hash,
        "generatorPath": str(Path(__file__).resolve()),
        "generatorSha256": base.sha256(Path(__file__).resolve()),
        "outcomesObservedBeforeLock": False,
        "unlockPolicy": "never overwrite; create a new versioned manifest if the protocol changes",
    }
    base.save(LOCK_PATH, lock)
    SHA_PATH.write_text(f"{manifest_hash}  {MANIFEST_PATH.name}\n", encoding="ascii")
    print(json.dumps(lock, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
