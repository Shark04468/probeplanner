# v0.2.1 v4 partial-case exact feasibility audit

This is a post-run diagnostic; the v4 first-execution results remain unchanged.

- Partial cases: 3
- Candidate-pool exact feasible: 2
- Candidate-pool infeasible: 1
- Solver timeouts: 0
- Selector failures: v021_v4_009_nearby_olfactory_amygdala, v021_v4_011_distributed_visl_ld
