#!/usr/bin/env python3
"""Post-hoc remediation run for the three failures exposed by v4."""

from __future__ import annotations

import hashlib
import json
import subprocess
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import run_v021_untouched_holdout as shared


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MANIFEST_PATH = HERE / "v021_v4_final_source_holdout_manifest.json"
BASELINE_RESULTS_PATH = HERE / "v021_v4_final_source_holdout_results.json"
FAILURE_ORACLE_PATH = HERE / "v021_v4_failure_oracle_results.json"
RESULTS_PATH = HERE / "v021_v4_failure_remediation_results.json"
REPORT_PATH = HERE / "V021_V4_FAILURE_REMEDIATION_REPORT.md"
FAILED_CASE_IDS = (
    "v021_v4_009_nearby_olfactory_amygdala",
    "v021_v4_011_distributed_visl_ld",
    "v021_v4_016_bilateral_coaa_ld",
)
SOURCE_FILES = (
    Path(__file__).resolve(),
    ROOT / "apps" / "backend-compat" / "src" / "optimizer_server.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "audit_registration_perturbation_sensitivity.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "benchmark_auto_probe_count_planning.py",
    ROOT / "apps" / "backend-compat" / "tests" / "test_validation_scripts.py",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save(path: Path, payload: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def main() -> int:
    started = time.perf_counter()
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    baseline = json.loads(BASELINE_RESULTS_PATH.read_text(encoding="utf-8"))
    first_run_failures = tuple(
        row["caseId"]
        for row in baseline["cases"]
        if not row.get("expectFailClosed") and row.get("coverageStatus") != "full"
    )
    if first_run_failures != FAILED_CASE_IDS:
        raise RuntimeError(f"Unexpected preserved v4 failure roster: {first_run_failures}")
    cases_by_id = {str(row["caseId"]): row for row in manifest["cases"]}
    current_cases = [cases_by_id[case_id] for case_id in FAILED_CASE_IDS]

    shared.atlas_util.configure_backend_environment(shared.PROFILE_ROOT, workers=1)
    server = shared.atlas_util.import_backend_server()
    server.load_atlas()
    if not server.atlas_loaded:
        raise RuntimeError(f"Atlas failed to load: {server.atlas_error}")
    targets = sorted({target for row in current_cases for target in row["requestedTargets"]})
    ontology = shared.atlas_util.apply_structure_tree_descendant_fallback(
        server, targets, shared.atlas_util.DEFAULT_STRUCTURES_JSON
    )
    expected_ids = {
        str(target): int(structure_id)
        for row in current_cases
        for target, structure_id in zip(row["requestedTargets"], row["targetStructureIds"])
    }
    resolved_ids = {
        str(row["acronym"]): int(row["regionId"])
        for row in ontology.get("updatedTargets", [])
    }
    mismatches = {
        target: {"expected": expected, "resolved": resolved_ids.get(target)}
        for target, expected in expected_ids.items()
        if resolved_ids.get(target) != expected
    }
    if mismatches:
        raise RuntimeError(f"Ontology target mismatch after remediation: {mismatches}")

    rows = []
    with server.app.app_context():
        for index, item in enumerate(current_cases, start=1):
            print(f"[v4 remediation {index}/{len(current_cases)}] {item['caseId']}", flush=True)
            result = shared.bench.run_case(
                server, shared.benchmark_case(item), workers=1, exact_validate=True
            )
            result = shared.enrich_result(server, result, tolerance_mm=0.025)
            rows.append(result)

    failures = [
        row["caseId"] for row in rows
        if row.get("coverageStatus") != "full"
        or not row.get("strictAuditPassed")
        or not row.get("optimalityMatch")
    ]
    summary = {
        "caseCount": len(rows),
        "fullCoverageCount": sum(1 for row in rows if row.get("coverageStatus") == "full"),
        "strictAuditPassCount": sum(1 for row in rows if row.get("strictAuditPassed")),
        "exactMatchCount": sum(1 for row in rows if row.get("optimalityMatch")),
        "ontologyMismatchCount": len(mismatches),
        "remainingFailureCaseIds": failures,
        "runtimeSec": time.perf_counter() - started,
        "acceptanceGate": "PASS" if not failures and not mismatches else "FAIL",
    }
    payload = {
        "schemaVersion": "probeplanner.v021_v4_failure_remediation.results.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "interpretation": "post_hoc_remediation_not_untouched",
        "gitHead": subprocess.check_output(
            ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True, encoding="utf-8"
        ).strip(),
        "sourceFiles": {
            str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in SOURCE_FILES
        },
        "v4ManifestSha256": sha256(MANIFEST_PATH),
        "v4OriginalResultsSha256": sha256(BASELINE_RESULTS_PATH),
        "v4FailureOracleSha256": sha256(FAILURE_ORACLE_PATH),
        "profileManifestSha256": sha256(shared.PROFILE_ROOT / "artifact_manifest.json"),
        "ontologyFallback": deepcopy(ontology),
        "summary": summary,
        "cases": rows,
    }
    save(RESULTS_PATH, payload)
    REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 v4 failure remediation",
                "",
                "This is a post-hoc remediation run, not untouched evidence.",
                "",
                f"- Full coverage: {summary['fullCoverageCount']}/{summary['caseCount']}",
                f"- Strict audit pass: {summary['strictAuditPassCount']}/{summary['caseCount']}",
                f"- Exact candidate-pool match: {summary['exactMatchCount']}/{summary['caseCount']}",
                f"- Ontology ID mismatches: {summary['ontologyMismatchCount']}",
                f"- Remaining failures: {', '.join(failures) if failures else 'none'}",
                f"- Acceptance gate: **{summary['acceptanceGate']}**",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    return 0 if summary["acceptanceGate"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
