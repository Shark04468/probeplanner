#!/usr/bin/env python3
"""Prove candidate-pool feasibility for the three v4 first-run partial cases."""

from __future__ import annotations

import hashlib
import json
import subprocess
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import run_v021_exact_oracle as shared


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
HOLDOUT_RESULTS_PATH = HERE / "v021_v4_final_source_holdout_results.json"
RESULTS_PATH = HERE / "v021_v4_failure_oracle_results.json"
REPORT_PATH = HERE / "V021_V4_FAILURE_ORACLE_REPORT.md"
MODEL_DIR = HERE / "v021_v4_failure_exact_models"
FAILED_CASE_IDS = (
    "v021_v4_009_nearby_olfactory_amygdala",
    "v021_v4_011_distributed_visl_ld",
    "v021_v4_016_bilateral_coaa_ld",
)
SOURCE_FILES = (
    Path(__file__).resolve(),
    ROOT / "apps" / "backend-compat" / "src" / "optimizer_server.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "audit_registration_perturbation_sensitivity.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "benchmark_auto_probe_count_planning.py",
    shared.OLD_ORACLE_RUNNER,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save(path: Path, payload: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def main() -> int:
    started = time.perf_counter()
    holdout = json.loads(HOLDOUT_RESULTS_PATH.read_text(encoding="utf-8"))
    by_id = {str(row["caseId"]): row for row in holdout["cases"]}
    if tuple(row["caseId"] for row in holdout["cases"] if row.get("coverageStatus") == "partial") != FAILED_CASE_IDS:
        raise RuntimeError("The preserved v4 partial-case roster changed")

    shared.atlas_util.configure_backend_environment(shared.PROFILE_ROOT, workers=1)
    server = shared.atlas_util.import_backend_server()
    server.load_atlas()
    if not server.atlas_loaded:
        raise RuntimeError(f"Atlas failed to load: {server.atlas_error}")
    targets = sorted({target for case_id in FAILED_CASE_IDS for target in by_id[case_id]["requestedTargets"]})
    ontology = shared.atlas_util.apply_structure_tree_descendant_fallback(
        server, targets, shared.atlas_util.DEFAULT_STRUCTURES_JSON
    )
    shared.oracle.CONFIG = {"solverTimeLimitSecPerCase": 120.0, "mipRelativeGap": 0.0}
    shared.oracle.HERE = HERE
    shared.oracle.MODEL_DIR = MODEL_DIR
    MODEL_DIR.mkdir(parents=True, exist_ok=True)

    rows = []
    with server.app.app_context():
        for index, case_id in enumerate(FAILED_CASE_IDS, start=1):
            print(f"[v4 failure oracle {index}/{len(FAILED_CASE_IDS)}] {case_id}", flush=True)
            source = by_id[case_id]
            request = deepcopy(source["plannerRequest"])
            params = request.setdefault("params", {})
            for key in ("computeWorkers", "candidateGenWorkers", "prefilterWorkers"):
                params[key] = 1
            case_started = time.perf_counter()
            pipeline = server._run_optimize_pipeline(request)
            candidates = list(pipeline.get("candidatePreview") or [])
            selected = list(pipeline.get("selected") or [])
            mode = str(source["targetingMode"])
            target_keys = [str(value) for value in source["requestedTargets"]]
            required = server._required_coverage_tokens(target_keys, mode)
            selected_covered = set()
            for candidate in selected:
                selected_covered |= server._candidate_coverage_tokens(candidate, target_keys, mode)
            token_candidate_counts = {
                token: sum(
                    1
                    for candidate in candidates
                    if token in server._candidate_coverage_tokens(candidate, target_keys, mode)
                )
                for token in sorted(required)
            }
            model = shared.oracle.build_exact_model(server, candidates, request)
            model_path, model_hash = shared.oracle.model_export(case_id, model)
            solved = shared.oracle.solve_model(model)
            rows.append(
                {
                    "caseId": case_id,
                    "requestedTargets": target_keys,
                    "targetingMode": mode,
                    "firstRunCoverageStatus": source["coverageStatus"],
                    "candidatePoolSize": len(candidates),
                    "tokenCandidateCounts": token_candidate_counts,
                    "plannerSelectedCount": len(selected),
                    "plannerSelectedFull": required <= selected_covered,
                    "plannerMissingTokens": sorted(required - selected_covered),
                    "modelPath": model_path,
                    "modelSha256": model_hash,
                    "conflictCount": len(model["conflicts"]),
                    **solved,
                    "caseRuntimeSec": time.perf_counter() - case_started,
                }
            )

    exact_feasible = [row for row in rows if row["solverStatus"] == "proven_optimal"]
    summary = {
        "partialCaseCount": len(rows),
        "candidatePoolExactFeasibleCount": len(exact_feasible),
        "candidatePoolInfeasibleCount": sum(1 for row in rows if row["solverStatus"] == "infeasible"),
        "timeoutCount": sum(1 for row in rows if row.get("timeout")),
        "selectorFailureCaseIds": [
            row["caseId"] for row in exact_feasible if not row["plannerSelectedFull"]
        ],
        "runtimeSec": time.perf_counter() - started,
    }
    payload = {
        "schemaVersion": "probeplanner.v021_v4_failure_oracle.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "interpretation": "post_run_diagnostic_on_preserved_v4_partial_cases",
        "gitHead": subprocess.check_output(
            ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True, encoding="utf-8"
        ).strip(),
        "sourceFiles": {
            str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in SOURCE_FILES
        },
        "v4HoldoutResultsSha256": sha256(HOLDOUT_RESULTS_PATH),
        "profileManifestSha256": sha256(shared.PROFILE_ROOT / "artifact_manifest.json"),
        "ontologyFallback": ontology,
        "summary": summary,
        "cases": rows,
    }
    save(RESULTS_PATH, payload)
    REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 v4 partial-case exact feasibility audit",
                "",
                "This is a post-run diagnostic; the v4 first-execution results remain unchanged.",
                "",
                f"- Partial cases: {summary['partialCaseCount']}",
                f"- Candidate-pool exact feasible: {summary['candidatePoolExactFeasibleCount']}",
                f"- Candidate-pool infeasible: {summary['candidatePoolInfeasibleCount']}",
                f"- Solver timeouts: {summary['timeoutCount']}",
                f"- Selector failures: {', '.join(summary['selectorFailureCaseIds']) or 'none'}",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
