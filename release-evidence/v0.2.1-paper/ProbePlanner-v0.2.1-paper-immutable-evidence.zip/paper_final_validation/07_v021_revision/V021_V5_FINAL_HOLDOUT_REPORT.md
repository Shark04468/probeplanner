# v0.2.1 untouched holdout

- Manifest locked at: `2026-08-17T02:53:09.797629+00:00`
- Run started at: `2026-08-17T02:53:18.366431+00:00`
- Manifest SHA-256: `b241575cb0f0bbccf54c2d166af1587655234a6c21fb4af2041a8fba5af0a7f1`
- Cases: 20
- Full / partial / fail-closed / error: 19 / 0 / 1 / 0
- Strict full-case failures: none
- Acceptance gate: **PASS**
