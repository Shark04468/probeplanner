# v0.2.1 untouched holdout

- Manifest locked at: `2026-08-16T18:10:20.810561+00:00`
- Run started at: `2026-08-16T18:10:50.716904+00:00`
- Manifest SHA-256: `ba0a24d97a69d5bbe648f75ad0ad3088a0aea2393f54c50ecf336907ed5c759c`
- Cases: 25
- Full / partial / fail-closed / error: 21 / 1 / 3 / 0
- Strict full-case failures: none
- Acceptance gate: **FAIL**
