#!/usr/bin/env python3
"""Run the historical 48-case oracle with targeted-mirror final source."""

from pathlib import Path

import run_v021_exact_oracle as runner


HERE = Path(__file__).resolve().parent
runner.REGRESSION_RESULTS = HERE / "targeted_mirror_source_historical_regression_results.json"
runner.CONTRACT_PATH = HERE / "targeted_mirror_source_exact_oracle_contract.json"
runner.CHECKPOINT_PATH = HERE / "targeted_mirror_source_exact_oracle_checkpoint.json"
runner.RESULTS_PATH = HERE / "targeted_mirror_source_exact_oracle_results.json"
runner.SUMMARY_PATH = HERE / "targeted_mirror_source_exact_oracle_summary.json"
runner.CSV_PATH = HERE / "targeted_mirror_source_exact_oracle_cases.csv"
runner.REPORT_PATH = HERE / "TARGETED_MIRROR_SOURCE_EXACT_ORACLE_REPORT.md"
runner.MODEL_DIR = HERE / "targeted_mirror_source_exact_models"
runner.SOURCE_FILES = (Path(__file__).resolve(), *runner.SOURCE_FILES)


if __name__ == "__main__":
    raise SystemExit(runner.main())
