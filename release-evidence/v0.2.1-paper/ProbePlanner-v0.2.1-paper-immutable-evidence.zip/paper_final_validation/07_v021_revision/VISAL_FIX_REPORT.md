# ProbePlanner v0.2.1 development fix report

## Scope

This is development evidence from the active worktree. It does not modify the frozen v0.2.0-paper holdout or its reported failures.

## Root cause

The descendant fallback computed planner coordinates from the bilateral Allen region centroid. For VISal this produced ML = -0.018 mm, effectively a midline seed, even though the target is a bilateral lateral cortical region. The target-local search was therefore centred at the wrong ML coordinate.

The pre-fix single-target run generated 2,394 specifications, deduplicated them to 1,206, rejected 247 at brain bounds, and rejected all remaining 959 at target coverage. Risk filtering and probe selection were downstream and were not the primary cause.

## Change

- Planner seeds now use a canonical left-hemisphere centroid; bilateral voxel counts remain unchanged for volume statistics.
- Bilateral planning mirrors the canonical centroid to the opposite hemisphere.
- Region-index caches are bound to centroid policy `canonical_left_v1`; older bilateral-centroid caches are rejected.
- Candidate telemetry now records per-source rejects and per-target coarse, refined, and final counts.
- Failed pipeline exceptions preserve candidate-generation and stage-breakdown diagnostics.

## Development reruns

| request | VISal ML mm | coarse | refined | final | selected probes | uncovered |
|---|---:|---:|---:|---:|---:|---|
| VISal | -3.706 | 65 | 32 | 8 | 1 | none |
| VISal + VISp + VISpm | -3.706 | 200 | 13 | 4 | 2 | none |
| VISal + CP | -3.706 | 79 | 8 | 2 | 2 | none |
| VISal + CA1 + CP + LP | -3.706 | 137 | 101 | 54 | 3 | none |

All reruns retained brain-bounds, continuous-risk, tip-in-target, depth, angle, and entry-spacing constraints.

## Reliability fixes

- Unequal probe counts now use rectangular Hungarian trajectory matching over both complete probe sets.
- The probe-count benchmark writes an atomic checkpoint after every case, resumes compatible completed cases, and optionally enforces a hard per-case subprocess timeout.
- The stability benchmark clamps internal workers to a memory budget and blocks concurrent runs on the same profile unless explicitly overridden.
- Supplementary JSON identifier sanitisation is covered by a regression test to prevent trailing-newline case IDs.

## Verification

- Backend test suite: 102 passed.
- One-case benchmark: full coverage, exact candidate-pool count match, expected count match.
- Checkpoint rerun: case was skipped from the compatible checkpoint.
- Hard-timeout smoke test: persisted status `timeout`; no worker process remained.

## Remaining gates

This fix resolves the reproduced VISal candidate-generation defect. It does not establish subject-specific MRI/CCF registration accuracy, skull/bregma/lambda accuracy, or surgical safety. Before a new release or manuscript claim, rerun the complete development benchmark, preregister a new untouched holdout, run the exact candidate-pool oracle, and repeat native-space containment and stability audits with one hash-bound profile.
