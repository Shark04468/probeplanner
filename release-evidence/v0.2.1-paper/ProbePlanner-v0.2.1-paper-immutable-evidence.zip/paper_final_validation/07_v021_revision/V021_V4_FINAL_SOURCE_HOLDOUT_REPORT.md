# v0.2.1 untouched holdout

- Manifest locked at: `2026-08-16T19:17:41.507052+00:00`
- Run started at: `2026-08-16T19:23:14.104932+00:00`
- Manifest SHA-256: `b3921fe300995a3a1faa061ef2635be57cfcfa903445679eb9c5b0b6bd0036af`
- Cases: 20
- Full / partial / fail-closed / error: 16 / 3 / 1 / 0
- Strict full-case failures: none
- Acceptance gate: **FAIL**
