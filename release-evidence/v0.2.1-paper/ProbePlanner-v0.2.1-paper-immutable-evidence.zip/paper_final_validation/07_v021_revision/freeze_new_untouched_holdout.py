#!/usr/bin/env python3
"""Freeze a planner-blind v0.2.1 holdout manifest and its hash lock."""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PROFILE_ROOT = Path(r"D:\mri_ccf\planner_artifacts\ambmc_true_outer_full")
REGION_MAP = PROFILE_ROOT / "region_map_v2.json"
PROFILE_MANIFEST = PROFILE_ROOT / "artifact_manifest.json"
OLD_HOLDOUT = HERE.parent / "02_prespecified_holdout" / "holdout_manifest.json"
V021_ORACLE_RESULTS = HERE / "v021_exact_oracle_results.json"
MANIFEST_PATH = HERE / "v021_untouched_holdout_manifest.json"
LOCK_PATH = HERE / "v021_untouched_holdout_lock.json"
SHA_PATH = HERE / "v021_untouched_holdout_manifest.sha256"
SOURCE_FILES = (
    ROOT / "apps" / "backend-compat" / "src" / "optimizer_server.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "audit_registration_perturbation_sensitivity.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "benchmark_auto_probe_count_planning.py",
)


def case(
    case_id: str,
    category: str,
    targets: list[str],
    mode: str = "single_hemisphere",
    depth_um: float = 7600.0,
    max_angle_deg: float = 10.0,
    expect_fail_closed: bool = False,
) -> dict[str, Any]:
    return {
        "caseId": case_id,
        "category": category,
        "requestedTargets": targets,
        "targetingMode": mode,
        "depthUm": depth_um,
        "maxAngleDeg": max_angle_deg,
        "expectFailClosed": expect_fail_closed,
    }


CASES = [
    case("v021_holdout_001_single_aca", "single", ["ACA"]),
    case("v021_holdout_002_single_audp", "single", ["AUDp"]),
    case("v021_holdout_003_single_tea", "single", ["TEa"]),
    case("v021_holdout_004_single_bla", "single", ["BLA"]),
    case("v021_holdout_005_single_md", "single", ["MD"]),
    case("v021_holdout_006_single_vpl", "single", ["VPL"]),
    case("v021_holdout_007_single_pag", "single", ["PAG"]),
    case("v021_holdout_008_single_vmh", "single", ["VMH"]),
    case("v021_holdout_009_nearby_prefrontal", "nearby_multi", ["ACA", "PL", "ILA"]),
    case("v021_holdout_010_nearby_temporal", "nearby_multi", ["AUDp", "TEa"]),
    case("v021_holdout_011_nearby_entorhinal", "nearby_multi", ["ENTl", "PERI", "ECT"]),
    case("v021_holdout_012_nearby_amygdala", "nearby_multi", ["BLA", "LA"]),
    case("v021_holdout_013_nearby_thalamic", "nearby_multi", ["MD", "VM", "VAL"]),
    case("v021_holdout_014_nearby_midbrain", "nearby_multi", ["SCs", "SCm", "PAG"]),
    case("v021_holdout_015_distributed_aca_vpl", "distributed", ["ACA", "VPL"]),
    case("v021_holdout_016_distributed_audp_md", "distributed", ["AUDp", "MD"]),
    case("v021_holdout_017_distributed_tea_bla", "distributed", ["TEa", "BLA"]),
    case("v021_holdout_018_distributed_orb_vpm", "distributed", ["ORB", "VPM"]),
    case("v021_holdout_019_distributed_pl_pag", "distributed", ["PL", "PAG"]),
    case("v021_holdout_020_distributed_vmh_vta", "distributed", ["VMH", "VTA"]),
    case("v021_holdout_021_bilateral_aca_md", "bilateral", ["ACA", "MD"], "bilateral_symmetric"),
    case("v021_holdout_022_bilateral_audp_vpl", "bilateral", ["AUDp", "VPL"], "bilateral_symmetric"),
    case("v021_holdout_023_bilateral_bla_vpm", "bilateral", ["BLA", "VPM"], "bilateral_symmetric"),
    case("v021_holdout_024_bilateral_tea_lp", "bilateral", ["TEa", "LP"], "bilateral_symmetric"),
    case("v021_holdout_025_bilateral_pag_vmh", "bilateral", ["PAG", "VMH"], "bilateral_symmetric"),
    case("v021_holdout_026_bilateral_orb_cp", "bilateral", ["ORB", "CP"], "bilateral_symmetric"),
    case("v021_holdout_027_quartet_cortex_thalamus", "high_order", ["ACA", "AUDp", "MD", "VPL"]),
    case("v021_holdout_028_quartet_temporal_deep", "high_order", ["TEa", "BLA", "PAG", "VMH"]),
    case("v021_holdout_029_quartet_frontostriatal", "high_order", ["ORB", "PL", "CP", "VPM"]),
    case("v021_holdout_030_quintet_temporal_thalamic", "high_order", ["AUDp", "TEa", "LP", "MD", "VPL"]),
    case("v021_holdout_031_fail_closed_shallow_pag", "negative_control", ["PAG"], depth_um=1800.0, max_angle_deg=5.0, expect_fail_closed=True),
    case("v021_holdout_032_fail_closed_shallow_vmh", "negative_control", ["VMH"], depth_um=2200.0, max_angle_deg=5.0, expect_fail_closed=True),
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save(path: Path, payload: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def git_value(*args: str) -> str:
    return subprocess.check_output(
        ["git", "-C", str(ROOT), *args], text=True, encoding="utf-8"
    ).strip()


def main() -> int:
    if MANIFEST_PATH.exists() or LOCK_PATH.exists() or SHA_PATH.exists():
        raise SystemExit("Holdout is already frozen; refusing to overwrite any lock artifact")
    region_map = json.loads(REGION_MAP.read_text(encoding="utf-8"))
    ids = {str(row["canonicalAcronym"]): int(row["id"]) for row in region_map["entries"]}
    case_ids = [row["caseId"] for row in CASES]
    if len(case_ids) != len(set(case_ids)):
        raise RuntimeError("Duplicate holdout case ID")
    signatures = [
        (row["targetingMode"], tuple(sorted(row["requestedTargets"])), row["depthUm"], row["maxAngleDeg"])
        for row in CASES
    ]
    if len(signatures) != len(set(signatures)):
        raise RuntimeError("Duplicate holdout case contract")
    missing = sorted({target for row in CASES for target in row["requestedTargets"] if target not in ids})
    if missing:
        raise RuntimeError(f"Targets missing from bound region map: {missing}")

    frozen_at = datetime.now(timezone.utc).isoformat()
    enriched_cases = []
    for row in CASES:
        enriched_cases.append(
            {
                **row,
                "targetStructureIds": [ids[target] for target in row["requestedTargets"]],
            }
        )
    manifest = {
        "schemaVersion": "probeplanner.prespecified_untouched_holdout.v2",
        "createdAt": frozen_at,
        "label": "v0.2.1 planner-blind untouched holdout benchmark",
        "outcomeState": "unobserved_at_lock",
        "caseSelection": "anatomically stratified fixed roster selected without importing or invoking ProbePlanner",
        "selectionAxes": [
            "single target",
            "nearby multi-target",
            "distributed multi-target",
            "bilateral symmetric",
            "four-to-five target",
            "prespecified shallow-depth fail-closed control",
        ],
        "methodSnapshot": {
            "gitHead": git_value("rev-parse", "HEAD"),
            "gitDirty": bool(git_value("status", "--porcelain")),
            "sourceFiles": {
                str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path)
                for path in SOURCE_FILES
            },
        },
        "profileRoot": str(PROFILE_ROOT.resolve()),
        "profileManifestSha256": sha256(PROFILE_MANIFEST),
        "regionMapV2Sha256": sha256(REGION_MAP),
        "historicalHoldoutManifestSha256": sha256(OLD_HOLDOUT),
        "preLockV021ExactOracleResultsSha256": sha256(V021_ORACLE_RESULTS),
        "plannerInvokedDuringSelection": False,
        "candidateOutcomesObservedDuringSelection": False,
        "caseCount": len(enriched_cases),
        "acceptanceGates": {
            "allCasesRetained": True,
            "noExecutionErrors": True,
            "fullCasesRequireIndependentStrictAudit": True,
            "negativeControlsMustFailClosed": True,
            "exactOracleRequiredForAllFullCases": True,
            "noOracleTimeouts": True,
        },
        "cases": enriched_cases,
    }
    save(MANIFEST_PATH, manifest)
    manifest_hash = sha256(MANIFEST_PATH)
    lock = {
        "schemaVersion": "probeplanner.untouched_holdout.lock.v1",
        "lockedAt": frozen_at,
        "status": "LOCKED_UNEXECUTED",
        "manifestPath": str(MANIFEST_PATH.resolve()),
        "manifestSha256": manifest_hash,
        "generatorPath": str(Path(__file__).resolve()),
        "generatorSha256": sha256(Path(__file__).resolve()),
        "outcomesObservedBeforeLock": False,
        "unlockPolicy": "never overwrite; create a new versioned manifest if the protocol changes",
    }
    save(LOCK_PATH, lock)
    SHA_PATH.write_text(f"{manifest_hash}  {MANIFEST_PATH.name}\n", encoding="ascii")
    print(json.dumps(lock, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
