# v0.2.1 exact candidate-pool oracle

This is a post-hoc audit on the fixed historical 48-case cohort.

- Contract SHA-256: `6f8b226e144e3330647b0d20213214f9934580dda04f32e8d4a9b301e7702e71`
- Proven optimal: 48/48
- Current exact matches: 48/48
- Historical exact matches: 47/48
- Exact minima unchanged: 43/48
- Acceptance gate: **PASS**

The certificate is limited to each regenerated strictly filtered candidate pool; it is not a continuous-space global optimum certificate.
