# v0.2.1 historical-manifest regression

This is a post-hoc regression run, not an untouched holdout.

- Contract SHA-256: `274bef5847921d7d17e2b615d8048a1264546fc11a8b2fe242fb2823b80d9769`
- Cases: 26
- Full / partial / fail-closed / error: 24 / 0 / 2 / 0
- Newly full cases: holdout_007_nearby_visual, holdout_012_distributed_cp_visal, holdout_021_quartet_ca1_cp_lp_visal
- Previously full regressions: none
- Strict failures among full cases: none
- Acceptance gate: **PASS**
