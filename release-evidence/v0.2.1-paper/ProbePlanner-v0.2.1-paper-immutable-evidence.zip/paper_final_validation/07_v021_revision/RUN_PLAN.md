# v0.2.1 development regression plan

## Objective

Measure whether the canonical-left centroid fix restores VISal feasibility without regressing cases that passed under v0.2.0-paper.

## Inputs

- Historical 26-case manifest: read-only, previously exposed to v0.2.0-paper.
- Active development source: bound by per-file SHA-256 and Git HEAD.
- Planning profile: `D:\mri_ccf\planner_artifacts\ambmc_true_outer_full`, bound by artifact-manifest SHA-256.
- Workers: 1.

## Interpretation

This is a post-hoc regression set, not a new untouched holdout. The original v0.2.0-paper results remain immutable.

## Gates

- No previously full-coverage case becomes partial, fail-closed, or error.
- Every new full-coverage case passes the independent strict audit.
- No execution error.
- All 26 cases are retained.

## Follow-up

After this gate, regenerate the strict candidate pools and run the independent MILP oracle. Only then freeze a new untouched holdout manifest.
