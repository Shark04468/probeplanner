# v0.2.1 historical-manifest regression

This is a post-hoc regression run, not an untouched holdout.

- Contract SHA-256: `2f57077beb7cfaf4d0bf98f4b2765378a0d5a07bf07ef4d24e33a66591bf228a`
- Cases: 26
- Full / partial / fail-closed / error: 24 / 0 / 2 / 0
- Newly full cases: holdout_007_nearby_visual, holdout_012_distributed_cp_visal, holdout_021_quartet_ca1_cp_lp_visal
- Previously full regressions: none
- Strict failures among full cases: none
- Acceptance gate: **PASS**
