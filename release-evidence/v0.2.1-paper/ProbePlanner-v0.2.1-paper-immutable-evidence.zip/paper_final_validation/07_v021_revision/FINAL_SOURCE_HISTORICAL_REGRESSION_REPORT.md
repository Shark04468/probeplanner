# v0.2.1 historical-manifest regression

This is a post-hoc regression run, not an untouched holdout.

- Contract SHA-256: `670df4aeb10bb613e085b907be7d552914b3a4cb0ec13a0855f50992eb3f2b89`
- Cases: 26
- Full / partial / fail-closed / error: 24 / 0 / 2 / 0
- Newly full cases: holdout_007_nearby_visual, holdout_012_distributed_cp_visal, holdout_021_quartet_ca1_cp_lp_visal
- Previously full regressions: none
- Strict failures among full cases: none
- Acceptance gate: **PASS**
