# v0.2.1 exact candidate-pool oracle

This is a post-hoc audit on the fixed historical 48-case cohort.

- Contract SHA-256: `2c3dc6914bdc7f8a59012f60762a343f0a451857320a013b8917c77330c03ad1`
- Proven optimal: 48/48
- Current exact matches: 48/48
- Historical exact matches: 47/48
- Exact minima unchanged: 45/48
- Acceptance gate: **PASS**

The certificate is limited to each regenerated strictly filtered candidate pool; it is not a continuous-space global optimum certificate.
