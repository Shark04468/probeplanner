# v0.2.1 v4 exact candidate-pool oracle

This audit covers every full case from the prespecified v4 first execution.

- Proven optimal: 16/16
- ProbePlanner exact matches: 16/16
- Timeouts: 0
- Acceptance gate: **PASS**

Certificates apply to regenerated strictly filtered candidate pools, not the continuous trajectory space.
