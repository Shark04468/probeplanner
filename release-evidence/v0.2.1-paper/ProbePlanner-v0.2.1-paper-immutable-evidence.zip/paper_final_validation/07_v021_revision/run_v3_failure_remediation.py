#!/usr/bin/env python3
"""Post-hoc remediation run for the four failures exposed by the v3 holdout."""

from __future__ import annotations

import hashlib
import json
import subprocess
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import run_v021_untouched_holdout as shared


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MANIFEST_PATH = HERE / "v021_v3_untouched_holdout_manifest.json"
BASELINE_RESULTS_PATH = HERE / "v021_v3_untouched_holdout_results.json"
CORRECTED_AUDIT_PATH = HERE / "v021_v3_untouched_coverage_reaudit.json"
CORRECTED_REPORT_PATH = HERE / "V021_V3_UNTOUCHED_COVERAGE_REAUDIT.md"
RESULTS_PATH = HERE / "v021_v3_failure_remediation_results.json"
REPORT_PATH = HERE / "V021_V3_FAILURE_REMEDIATION_REPORT.md"
FAILED_CASE_IDS = (
    "v021_v3_012_nearby_hypothalamic",
    "v021_v3_016_distributed_ot_snr",
    "v021_v3_018_bilateral_visrl_re",
    "v021_v3_020_bilateral_cla_po",
)
SOURCE_FILES = (
    Path(__file__).resolve(),
    ROOT / "apps" / "backend-compat" / "src" / "optimizer_server.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "audit_registration_perturbation_sensitivity.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "benchmark_auto_probe_count_planning.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "build_strict_final_benchmark.py",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save(path: Path, payload: Any) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def corrected_status(row: dict[str, Any]) -> tuple[str, list[str]]:
    targets = [str(value) for value in row.get("requestedTargets") or []]
    if row.get("targetingMode") == "bilateral_symmetric":
        required = {f"{target}:{side}" for target in targets for side in ("left", "right")}
    else:
        required = set(targets)
    covered = {str(value) for value in row.get("coveredTokens") or []}
    missing = sorted(required - covered)
    if not missing and row.get("selectedProbes"):
        return "full", missing
    if not row.get("selectedProbes"):
        return "fail-closed", missing
    return "partial", missing


def build_reaudit(baseline: dict[str, Any]) -> dict[str, Any]:
    rows = []
    for row in baseline["cases"]:
        status, missing = corrected_status(row)
        rows.append(
            {
                "caseId": row["caseId"],
                "originalCoverageStatus": row.get("coverageStatus"),
                "correctedCoverageStatus": status,
                "requiredCoverageUnits": row.get("requiredCoverageUnits"),
                "coveredCoverageUnits": row.get("coveredCoverageUnits"),
                "missingCoverageTokens": missing,
                "expectFailClosed": bool(row.get("expectFailClosed")),
                "correctedStrictAuditPassed": bool(status == "full" and row.get("strictAuditPassed")),
            }
        )
    false_full = [
        row["caseId"] for row in rows
        if row["originalCoverageStatus"] == "full" and row["correctedCoverageStatus"] != "full"
    ]
    positive_failures = [
        row["caseId"] for row in rows
        if not row["expectFailClosed"] and row["correctedCoverageStatus"] != "full"
    ]
    return {
        "schemaVersion": "probeplanner.v021_v3_coverage_reaudit.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "interpretation": "post_hoc_correction_from_preserved_required_and_covered_tokens",
        "sourceResultsSha256": sha256(BASELINE_RESULTS_PATH),
        "caseCount": len(rows),
        "correctedFullCoverageCount": sum(1 for row in rows if row["correctedCoverageStatus"] == "full"),
        "correctedPartialCoverageCount": sum(1 for row in rows if row["correctedCoverageStatus"] == "partial"),
        "correctedFailClosedCount": sum(1 for row in rows if row["correctedCoverageStatus"] == "fail-closed"),
        "falseFullCaseIds": false_full,
        "positiveFailureCaseIds": positive_failures,
        "rows": rows,
    }


def main() -> int:
    started = time.perf_counter()
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    baseline = json.loads(BASELINE_RESULTS_PATH.read_text(encoding="utf-8"))
    reaudit = build_reaudit(baseline)
    if tuple(reaudit["positiveFailureCaseIds"]) != FAILED_CASE_IDS:
        raise RuntimeError(f"Unexpected corrected failure roster: {reaudit['positiveFailureCaseIds']}")
    save(CORRECTED_AUDIT_PATH, reaudit)
    CORRECTED_REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 v3 untouched coverage re-audit",
                "",
                f"- Corrected full / partial / fail-closed: {reaudit['correctedFullCoverageCount']} / {reaudit['correctedPartialCoverageCount']} / {reaudit['correctedFailClosedCount']}",
                f"- False full cases: {', '.join(reaudit['falseFullCaseIds'])}",
                f"- Positive failures: {', '.join(reaudit['positiveFailureCaseIds'])}",
                "",
            ]
        ),
        encoding="utf-8",
    )

    cases_by_id = {str(row["caseId"]): row for row in manifest["cases"]}
    current_cases = [cases_by_id[case_id] for case_id in FAILED_CASE_IDS]
    shared.atlas_util.configure_backend_environment(shared.PROFILE_ROOT, workers=1)
    server = shared.atlas_util.import_backend_server()
    server.load_atlas()
    if not server.atlas_loaded:
        raise RuntimeError(f"Atlas failed to load: {server.atlas_error}")
    targets = sorted({target for row in current_cases for target in row["requestedTargets"]})
    ontology = shared.atlas_util.apply_structure_tree_descendant_fallback(
        server, targets, shared.atlas_util.DEFAULT_STRUCTURES_JSON
    )
    rows = []
    with server.app.app_context():
        for index, item in enumerate(current_cases, start=1):
            print(f"[remediation {index}/{len(current_cases)}] {item['caseId']}", flush=True)
            result = shared.bench.run_case(
                server, shared.benchmark_case(item), workers=1, exact_validate=True
            )
            result = shared.enrich_result(server, result, tolerance_mm=0.025)
            before = next(row for row in reaudit["rows"] if row["caseId"] == item["caseId"])
            result["beforeCoverageStatus"] = before["correctedCoverageStatus"]
            result["beforeMissingCoverageTokens"] = before["missingCoverageTokens"]
            rows.append(result)

    failures = [
        row["caseId"] for row in rows
        if row.get("coverageStatus") != "full"
        or not row.get("strictAuditPassed")
        or not row.get("optimalityMatch")
    ]
    contract = {
        "schemaVersion": "probeplanner.v021_v3_failure_remediation.contract.v1",
        "interpretation": "post_hoc_remediation_not_untouched",
        "gitHead": subprocess.check_output(
            ["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True, encoding="utf-8"
        ).strip(),
        "sourceFiles": {
            str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in SOURCE_FILES
        },
        "v3ManifestSha256": sha256(MANIFEST_PATH),
        "v3OriginalResultsSha256": sha256(BASELINE_RESULTS_PATH),
        "v3CoverageReauditSha256": sha256(CORRECTED_AUDIT_PATH),
        "profileManifestSha256": sha256(shared.PROFILE_ROOT / "artifact_manifest.json"),
        "workers": 1,
        "exactValidation": True,
    }
    summary = {
        "caseCount": len(rows),
        "fullCoverageCount": sum(1 for row in rows if row.get("coverageStatus") == "full"),
        "strictAuditPassCount": sum(1 for row in rows if row.get("strictAuditPassed")),
        "exactMatchCount": sum(1 for row in rows if row.get("optimalityMatch")),
        "remainingFailureCaseIds": failures,
        "runtimeSec": time.perf_counter() - started,
        "acceptanceGate": "PASS" if not failures else "FAIL",
    }
    payload = {
        "schemaVersion": "probeplanner.v021_v3_failure_remediation.results.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "contract": contract,
        "ontologyFallback": deepcopy(ontology),
        "summary": summary,
        "cases": rows,
    }
    save(RESULTS_PATH, payload)
    REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 v3 failure remediation",
                "",
                "This is a post-hoc remediation run, not untouched evidence.",
                "",
                f"- Full coverage: {summary['fullCoverageCount']}/{summary['caseCount']}",
                f"- Strict audit pass: {summary['strictAuditPassCount']}/{summary['caseCount']}",
                f"- Exact candidate-pool match: {summary['exactMatchCount']}/{summary['caseCount']}",
                f"- Remaining failures: {', '.join(failures) if failures else 'none'}",
                f"- Acceptance gate: **{summary['acceptanceGate']}**",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
