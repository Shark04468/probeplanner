# ProbePlanner v0.2.1 final-source validation

## Decision

**Planner software gate: PASS. Overall pre-submission verdict: REQUIRES REVISION.**

The final planner source passed the prespecified v5 holdout and all candidate-pool exact-oracle gates. This closes the discovered ontology, incomplete-selector, and bilateral candidate-generation defects. It does not establish subject-specific anatomical accuracy, skull-landmark accuracy, native-space safety, or continuous-space global optimality.

## Preserved failure and diagnosis

The v4 manifest was locked before execution (`b3921fe300995a3a1faa061ef2635be57cfcfa903445679eb9c5b0b6bd0036af`). Its first execution remains unchanged: 16 full, 3 partial, one expected fail-closed, and gate **FAIL**.

| v4 partial case | Preserved failure | Exact diagnosis |
|---|---|---|
| `COAa, COAp, NLOT` | `COAa` uncovered | Candidate pool feasible at 3 probes; incomplete selector stopped at 2. |
| `VISl, LD` | `VISl` uncovered | Candidate pool feasible at 2 probes; incomplete selector stopped at 1. The stale seed also mapped `VISl` to VISam ID 394 instead of exact ontology ID 409. |
| bilateral `COAa, LD` | `COAa:left` uncovered | Candidate pool infeasible because no candidate covered `COAa:left`. |

## Final-source changes

1. Exact ontology acronyms now override stale planner seeds, and the active acronym record is corrected consistently.
2. Incomplete non-bilateral selections now use bounded exact token-cover completion.
3. Bilateral coarse candidates retain explicit target-side tokens.
4. Mirror closure is applied only to target-side tokens missing from the coarse pool; both ML and azimuth are mirrored.
5. Per-target, per-side diversity seeds and mirror telemetry make the recovery path auditable without doubling normal bilateral pools.

## Validation results

| Evidence | Outcome | Gate |
|---|---|---|
| v4 post-hoc remediation | 3/3 full, 3/3 strict audit, 3/3 exact match, 0 ontology mismatches | PASS |
| Final-source historical regression | 24 full, 0 partial, 2 expected fail-closed; 24/24 strict; no previously-full regressions | PASS |
| Final-source historical exact oracle | 48/48 proven optimal, 48/48 planner exact match, 0 timeouts | PASS |
| v5 untouched holdout | 19/19 positive cases full and strict; 1/1 negative control fail-closed; 0 partial, 0 errors | PASS |
| v5 exact oracle | 19/19 proven optimal and exact match; 0 timeouts | PASS |

The v5 manifest was frozen before outcome observation with SHA-256 `b241575cb0f0bbccf54c2d166af1587655234a6c21fb4af2041a8fba5af0a7f1`. Its run contract is `8bd76e259b1d2a5d5d29e6832339635a3341e482e95b53c0e42e5bf715a311ce`; the v5 exact-oracle contract is `effe3bb5f58efff6c75ff2997d9c774c8a631f0b8769f005e46fc61b4b74eec8`.

All final-source runs bind optimizer SHA-256 `dec6c2153b4d3ff2d3241ee12ec00abea856795828f9a2b19be85bc56cea065c` and profile-manifest SHA-256 `ebaa6bade50c34f5d84fccd3092bef7dc904cada6e983f31af363ec61ada8222`.

## Claim boundary

Supported: full coverage and strict constraint behavior on the locked cohorts; fail-closed behavior; and minimum probe count within each regenerated strictly filtered candidate pool.

Not supported: continuous-space global optimum, subject-specific landmark TRE, bregma/lambda or skull localization accuracy, individual-animal native-space safety, vascular/ventricular avoidance where masks are unavailable, or successful independent-machine reproduction.

The project-level verdict therefore remains **REQUIRES REVISION** until real independent anatomical/skull landmarks and a same-subject native MRI/CT validation package are available.

## Evidence index

- `V021_V4_FINAL_SOURCE_HOLDOUT_REPORT.md`: preserved first-execution failure.
- `V021_V4_FAILURE_ORACLE_REPORT.md`: exact diagnosis of all v4 partial cases.
- `V021_V4_TARGETED_MIRROR_REMEDIATION_REPORT.md`: post-hoc repair evidence.
- `TARGETED_MIRROR_SOURCE_HISTORICAL_REGRESSION_REPORT.md`: final-source historical regression.
- `TARGETED_MIRROR_SOURCE_EXACT_ORACLE_REPORT.md`: final-source 48-case exact oracle.
- `V021_V5_FINAL_HOLDOUT_REPORT.md`: prespecified final untouched holdout.
- `V021_V5_EXACT_ORACLE_REPORT.md`: exact certificates for every v5 full case.
- `v021_final_validation_figure_data.csv`: source table for Supplementary Figure S6.
- `paper/figures/supplementary_figure_s6_v021_final_validation_manifest.json`: hashes for the figure inputs, generator, and PNG/PDF/SVG exports.
