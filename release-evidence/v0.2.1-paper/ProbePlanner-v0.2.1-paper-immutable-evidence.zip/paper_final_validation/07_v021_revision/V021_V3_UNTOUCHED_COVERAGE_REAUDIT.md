# v0.2.1 v3 untouched coverage re-audit

- Corrected full / partial / fail-closed: 19 / 3 / 3
- False full cases: v021_v3_018_bilateral_visrl_re, v021_v3_020_bilateral_cla_po
- Positive failures: v021_v3_012_nearby_hypothalamic, v021_v3_016_distributed_ot_snr, v021_v3_018_bilateral_visrl_re, v021_v3_020_bilateral_cla_po
