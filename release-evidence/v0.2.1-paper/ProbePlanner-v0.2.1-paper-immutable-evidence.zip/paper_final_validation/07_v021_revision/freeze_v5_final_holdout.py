#!/usr/bin/env python3
"""Freeze the post-v4 final-source v5 holdout before planner execution."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import freeze_new_untouched_holdout as base


HERE = Path(__file__).resolve().parent
MANIFEST_PATH = HERE / "v021_v5_final_holdout_manifest.json"
LOCK_PATH = HERE / "v021_v5_final_holdout_lock.json"
SHA_PATH = HERE / "v021_v5_final_holdout_manifest.sha256"
V4_LOCK_PATH = HERE / "v021_v4_final_source_holdout_lock.json"
TEST_FILE = base.ROOT / "apps" / "backend-compat" / "tests" / "test_validation_scripts.py"
POST_V4_REGRESSION = HERE / "targeted_mirror_source_historical_regression_results.json"
POST_V4_ORACLE = HERE / "targeted_mirror_source_exact_oracle_results.json"
PRIOR_MANIFESTS = (
    HERE.parent / "02_prespecified_holdout" / "holdout_manifest.json",
    HERE / "v021_untouched_holdout_manifest.json",
    HERE / "v021_v3_untouched_holdout_manifest.json",
    HERE / "v021_v4_final_source_holdout_manifest.json",
)


CASES = [
    base.case("v021_v5_001_single_scsg", "single", ["SCsg"]),
    base.case("v021_v5_002_single_dmh", "single", ["DMH"]),
    base.case("v021_v5_003_single_ep", "single", ["EP"]),
    base.case("v021_v5_004_single_tt", "single", ["TT"]),
    base.case("v021_v5_005_single_par", "single", ["PAR"]),
    base.case("v021_v5_006_single_vplpc", "single", ["VPLpc"]),
    base.case("v021_v5_007_nearby_superior_colliculus", "nearby_multi", ["SCsg", "SCzo"]),
    base.case("v021_v5_008_nearby_hypothalamic", "nearby_multi", ["DMH", "PH"]),
    base.case("v021_v5_009_nearby_olfactory", "nearby_multi", ["DP", "TT", "TRS"]),
    base.case("v021_v5_010_nearby_subiculum", "nearby_multi", ["PRE", "PAR", "POST"]),
    base.case("v021_v5_011_distributed_ep_ad", "distributed", ["EP", "AD"]),
    base.case("v021_v5_012_distributed_vplpc_visam", "distributed", ["VPLpc", "VISam"]),
    base.case("v021_v5_013_distributed_sczo_mob", "distributed", ["SCzo", "MOB"]),
    base.case("v021_v5_014_bilateral_dmh_vplpc", "bilateral", ["DMH", "VPLpc"], "bilateral_symmetric"),
    base.case("v021_v5_015_bilateral_ep_visam", "bilateral", ["EP", "VISam"], "bilateral_symmetric"),
    base.case("v021_v5_016_bilateral_par_rt", "bilateral", ["PAR", "RT"], "bilateral_symmetric"),
    base.case("v021_v5_017_triad_midbrain_hypothalamus", "high_order", ["SCsg", "DMH", "EP"]),
    base.case("v021_v5_018_quartet_distributed", "high_order", ["TT", "TRS", "AD", "VPLpc"]),
    base.case("v021_v5_019_quintet_distributed", "high_order", ["SCzo", "PH", "PAR", "MOB", "LD"]),
    base.case(
        "v021_v5_020_fail_closed_shallow_ph",
        "negative_control",
        ["PH"],
        depth_um=1500.0,
        max_angle_deg=5.0,
        expect_fail_closed=True,
    ),
]


def signature(row):
    return (
        str(row["targetingMode"]),
        tuple(sorted(str(value) for value in row["requestedTargets"])),
        float(row["depthUm"]),
        float(row["maxAngleDeg"]),
    )


def main() -> int:
    if MANIFEST_PATH.exists() or LOCK_PATH.exists() or SHA_PATH.exists():
        raise SystemExit("v5 holdout is already frozen; refusing to overwrite lock artifacts")
    if not POST_V4_REGRESSION.exists() or not POST_V4_ORACLE.exists():
        raise RuntimeError("Post-v4 historical regression and exact oracle must finish before v5 lock")
    regression = json.loads(POST_V4_REGRESSION.read_text(encoding="utf-8"))
    oracle = json.loads(POST_V4_ORACLE.read_text(encoding="utf-8"))
    if regression["summary"]["acceptanceGate"] != "PASS":
        raise RuntimeError("Post-v4 historical regression did not pass")
    if oracle["summary"]["acceptanceGate"] != "PASS":
        raise RuntimeError("Post-v4 historical exact oracle did not pass")

    region_map = json.loads(base.REGION_MAP.read_text(encoding="utf-8"))
    ids = {str(row["canonicalAcronym"]): int(row["id"]) for row in region_map["entries"]}
    missing = sorted({target for row in CASES for target in row["requestedTargets"] if target not in ids})
    if missing:
        raise RuntimeError(f"Targets missing from bound region map: {missing}")
    if len({row["caseId"] for row in CASES}) != len(CASES):
        raise RuntimeError("Duplicate v5 holdout case ID")
    prior_signatures = set()
    for path in PRIOR_MANIFESTS:
        payload = json.loads(path.read_text(encoding="utf-8"))
        prior_signatures.update(signature(row) for row in payload["cases"])
    duplicates = [row["caseId"] for row in CASES if signature(row) in prior_signatures]
    if duplicates:
        raise RuntimeError(f"v5 case contracts duplicate prior manifests: {duplicates}")

    v4_lock = json.loads(V4_LOCK_PATH.read_text(encoding="utf-8"))
    frozen_at = datetime.now(timezone.utc).isoformat()
    manifest = {
        "schemaVersion": "probeplanner.prespecified_untouched_holdout.v5",
        "createdAt": frozen_at,
        "label": "v0.2.1 post-v4 final-source prespecified untouched holdout benchmark",
        "outcomeState": "unobserved_at_lock",
        "supersedesManifestSha256": v4_lock["manifestSha256"],
        "supersessionReason": (
            "v4 exposed ontology resolution, non-bilateral completion, and bilateral mirror-closure defects; "
            "v5 binds the remediated source after historical regression and exact-oracle gates"
        ),
        "caseSelection": (
            "anatomically stratified fixed roster selected from the bound ontology without invoking "
            "candidate generation, scoring, optimization, or result preflight"
        ),
        "methodSnapshot": {
            "gitHead": base.git_value("rev-parse", "HEAD"),
            "gitDirty": bool(base.git_value("status", "--porcelain")),
            "sourceFiles": {
                str(path.relative_to(base.ROOT)).replace("\\", "/"): base.sha256(path)
                for path in (*base.SOURCE_FILES, TEST_FILE)
            },
        },
        "verificationBeforeLock": {
            "backendTestCommand": "python -m pytest apps/backend-compat/tests -q",
            "backendTestResult": "112 passed",
            "postV4HistoricalRegressionSha256": base.sha256(POST_V4_REGRESSION),
            "postV4HistoricalExactOracleSha256": base.sha256(POST_V4_ORACLE),
        },
        "profileRoot": str(base.PROFILE_ROOT.resolve()),
        "profileManifestSha256": base.sha256(base.PROFILE_MANIFEST),
        "regionMapV2Sha256": base.sha256(base.REGION_MAP),
        "plannerInvokedDuringSelection": False,
        "candidateOutcomesObservedDuringSelection": False,
        "caseCount": len(CASES),
        "acceptanceGates": {
            "allCasesRetained": True,
            "noExecutionErrors": True,
            "fullCasesRequireIndependentStrictAudit": True,
            "negativeControlsMustFailClosed": True,
            "exactOracleRequiredForAllFullCases": True,
            "noOracleTimeouts": True,
        },
        "cases": [
            {**row, "targetStructureIds": [ids[target] for target in row["requestedTargets"]]}
            for row in CASES
        ],
    }
    base.save(MANIFEST_PATH, manifest)
    manifest_hash = base.sha256(MANIFEST_PATH)
    lock = {
        "schemaVersion": "probeplanner.untouched_holdout.lock.v1",
        "lockedAt": frozen_at,
        "status": "LOCKED_UNEXECUTED",
        "manifestPath": str(MANIFEST_PATH.resolve()),
        "manifestSha256": manifest_hash,
        "generatorPath": str(Path(__file__).resolve()),
        "generatorSha256": base.sha256(Path(__file__).resolve()),
        "outcomesObservedBeforeLock": False,
        "unlockPolicy": "never overwrite; create a new versioned manifest if the protocol changes",
    }
    base.save(LOCK_PATH, lock)
    SHA_PATH.write_text(f"{manifest_hash}  {MANIFEST_PATH.name}\n", encoding="ascii")
    print(json.dumps(lock, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
