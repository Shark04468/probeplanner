#!/usr/bin/env python3
"""Run an independent exact candidate-pool oracle for all full v4 holdout cases."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

import run_v021_exact_oracle as runner


HERE = Path(__file__).resolve().parent
MANIFEST_PATH = HERE / "v021_v4_final_source_holdout_manifest.json"
LOCK_PATH = HERE / "v021_v4_final_source_holdout_lock.json"
HOLDOUT_RESULTS_PATH = HERE / "v021_v4_final_source_holdout_results.json"

runner.CONTRACT_PATH = HERE / "v021_v4_exact_oracle_contract.json"
runner.CHECKPOINT_PATH = HERE / "v021_v4_exact_oracle_checkpoint.json"
runner.RESULTS_PATH = HERE / "v021_v4_exact_oracle_results.json"
runner.SUMMARY_PATH = HERE / "v021_v4_exact_oracle_summary.json"
runner.CSV_PATH = HERE / "v021_v4_exact_oracle_cases.csv"
runner.REPORT_PATH = HERE / "V021_V4_EXACT_ORACLE_REPORT.md"
runner.MODEL_DIR = HERE / "v021_v4_exact_models"
runner.SOURCE_FILES = (Path(__file__).resolve(), *runner.SOURCE_FILES)


def build_contract(args: Any) -> dict[str, Any]:
    holdout = json.loads(HOLDOUT_RESULTS_PATH.read_text(encoding="utf-8"))
    full_count = sum(1 for row in holdout["cases"] if row.get("coverageStatus") == "full")
    return {
        "schemaVersion": "probeplanner.v021_v4_exact_oracle.contract.v1",
        "interpretation": "post_run_exact_oracle_for_all_full_prespecified_v4_holdout_cases",
        "gitHead": runner.git_value("rev-parse", "HEAD"),
        "gitDirty": bool(runner.git_value("status", "--porcelain")),
        "sourceFiles": {
            str(path.relative_to(runner.ROOT)).replace("\\", "/"): runner.sha256(path)
            for path in runner.SOURCE_FILES
        },
        "manifestSha256": runner.sha256(MANIFEST_PATH),
        "lockSha256": runner.sha256(LOCK_PATH),
        "firstRunHoldoutResultsSha256": runner.sha256(HOLDOUT_RESULTS_PATH),
        "profileRoot": str(runner.PROFILE_ROOT.resolve()),
        "profileManifestSha256": runner.sha256(runner.PROFILE_ROOT / "artifact_manifest.json"),
        "solver": "SciPy milp / HiGHS binary MILP",
        "solverTimeLimitSecPerCase": float(args.solver_time_limit_sec),
        "mipRelativeGap": 0.0,
        "workers": int(args.workers),
        "requestWorkerOverrideKeys": [
            "computeWorkers", "candidateGenWorkers", "prefilterWorkers"
        ],
        "fixedCohortCaseCount": full_count,
        "claimScope": "minimum-cardinality feasible set within each regenerated strictly filtered candidate pool",
    }


def load_cases() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    holdout = json.loads(HOLDOUT_RESULTS_PATH.read_text(encoding="utf-8"))
    rows = []
    for source in holdout["cases"]:
        if source.get("coverageStatus") != "full":
            continue
        count = int(source["selectedProbeCount"])
        rows.append(
            {
                "cohort": "v4_untouched_full",
                "caseId": str(source["caseId"]),
                "requestedTargets": list(source["requestedTargets"]),
                "targetingMode": str(source["targetingMode"]),
                "plannerRequest": deepcopy(source["plannerRequest"]),
                "historicalPlannerCount": count,
                "historicalExactMinimumCount": count,
                "historicalExactMatch": True,
                "regressionPlannerCount": count,
            }
        )
    if len(rows) != int(holdout["summary"]["fullCoverageCount"]):
        raise RuntimeError("Full-case roster does not match the frozen first-run holdout summary")
    return rows, {}


def summarize(rows: list[dict[str, Any]], _unused: dict[str, Any]) -> dict[str, Any]:
    expected = int(build_contract(ARGS)["fixedCohortCaseCount"])
    certified = [row for row in rows if row.get("solverStatus") == "proven_optimal"]
    matches = [row for row in certified if row.get("exactMatchRerun")]
    failures = []
    if len(rows) != expected:
        failures.append("full_case_count_mismatch")
    if len(certified) != expected:
        failures.append("not_all_full_cases_proven_optimal")
    if len(matches) != expected:
        failures.append("planner_not_exact_on_all_full_cases")
    if any(row.get("timeout") for row in rows):
        failures.append("oracle_timeout")
    if any(row.get("solverStatus") in {"error", "infeasible"} for row in rows):
        failures.append("oracle_error_or_infeasible")
    return {
        "totalCaseCount": len(rows),
        "exactCertifiedCaseCount": len(certified),
        "probePlannerExactMatchCount": len(matches),
        "probePlannerExactMatchRateAmongCertified": len(matches) / max(1, len(certified)),
        "historicalProbePlannerExactMatchCount": expected,
        "exactMinimumUnchangedCount": sum(
            1 for row in certified if row.get("exactMinimumMatchesHistorical")
        ),
        "plannerCountChangedCount": sum(
            1 for row in rows if not row.get("replayCountMatchesHistorical")
        ),
        "solverStatusCounts": {
            status: sum(1 for row in rows if row.get("solverStatus") == status)
            for status in sorted({str(row.get("solverStatus")) for row in rows})
        },
        "timeoutCount": sum(1 for row in rows if row.get("timeout")),
        "acceptanceGate": "PASS" if not failures else "FAIL",
        "gateFailures": failures,
    }


ARGS: Any = None


def main() -> int:
    global ARGS
    ARGS = runner.build_parser().parse_args()
    runner.build_parser = lambda: _fixed_parser(ARGS)
    runner.build_contract = build_contract
    runner.load_cases = load_cases
    runner.summarize = summarize
    code = runner.main()
    summary = json.loads(runner.SUMMARY_PATH.read_text(encoding="utf-8"))
    runner.REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 v4 exact candidate-pool oracle",
                "",
                "This audit covers every full case from the prespecified v4 first execution.",
                "",
                f"- Proven optimal: {summary['exactCertifiedCaseCount']}/{summary['totalCaseCount']}",
                f"- ProbePlanner exact matches: {summary['probePlannerExactMatchCount']}/{summary['totalCaseCount']}",
                f"- Timeouts: {summary['timeoutCount']}",
                f"- Acceptance gate: **{summary['acceptanceGate']}**",
                "",
                "Certificates apply to regenerated strictly filtered candidate pools, not the continuous trajectory space.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return code


def _fixed_parser(args: Any) -> Any:
    class FixedParser:
        @staticmethod
        def parse_args(_argv: Any = None) -> Any:
            return args

    return FixedParser()


if __name__ == "__main__":
    raise SystemExit(main())
