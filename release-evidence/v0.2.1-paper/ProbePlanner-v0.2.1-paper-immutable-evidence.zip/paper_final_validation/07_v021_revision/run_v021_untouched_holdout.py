#!/usr/bin/env python3
"""Execute the already locked v0.2.1 untouched holdout exactly once."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
import subprocess
import sys
import time
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SCRIPT_DIR = ROOT / "apps" / "backend-compat" / "scripts"
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import audit_registration_perturbation_sensitivity as atlas_util  # noqa: E402
import benchmark_auto_probe_count_planning as bench  # noqa: E402
import build_strict_final_benchmark as strict  # noqa: E402


PROFILE_ROOT = Path(r"D:\mri_ccf\planner_artifacts\ambmc_true_outer_full")
MANIFEST_PATH = HERE / "v021_untouched_holdout_manifest.json"
LOCK_PATH = HERE / "v021_untouched_holdout_lock.json"
CONTRACT_PATH = HERE / "v021_untouched_holdout_run_contract.json"
CHECKPOINT_PATH = HERE / "v021_untouched_holdout_checkpoint.json"
RESULTS_PATH = HERE / "v021_untouched_holdout_results.json"
SUMMARY_PATH = HERE / "v021_untouched_holdout_summary.json"
CASE_CSV_PATH = HERE / "v021_untouched_holdout_cases.csv"
PROBE_CSV_PATH = HERE / "v021_untouched_holdout_probes.csv"
REPORT_PATH = HERE / "V021_UNTOUCHED_HOLDOUT_REPORT.md"
SOURCE_FILES = (
    Path(__file__).resolve(),
    ROOT / "apps" / "backend-compat" / "src" / "optimizer_server.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "audit_registration_perturbation_sensitivity.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "benchmark_auto_probe_count_planning.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "build_strict_final_benchmark.py",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_hash(payload: Any) -> str:
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def save(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def git_value(*args: str) -> str:
    return subprocess.check_output(
        ["git", "-C", str(ROOT), *args], text=True, encoding="utf-8"
    ).strip()


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    low = int(position)
    high = min(len(ordered) - 1, low + 1)
    weight = position - low
    return float(ordered[low] * (1.0 - weight) + ordered[high] * weight)


def benchmark_case(row: dict[str, Any]) -> bench.BenchmarkCase:
    return bench.BenchmarkCase(
        case_id=str(row["caseId"]),
        case_type=str(row["category"]),
        purpose="Prespecified v0.2.1 untouched holdout evaluation.",
        requested_targets=tuple(str(value) for value in row["requestedTargets"]),
        targeting_mode=str(row["targetingMode"]),
        expected_probe_count=None,
        expect_fail_closed=bool(row.get("expectFailClosed", False)),
        depth_um=float(row.get("depthUm", 7600.0)),
        max_angle_deg=float(row.get("maxAngleDeg", 10.0)),
    )


def hard_violations(probe: dict[str, Any], tolerance_mm: float) -> list[str]:
    failures = []
    if probe.get("brainContainmentPassed") is not True:
        failures.append("brain_containment")
    if probe.get("tipInTarget") is not True:
        failures.append("tip_in_target")
    overshoot = probe.get("distalOvershootMm")
    if overshoot is None or float(overshoot) > tolerance_mm + 1e-9:
        failures.append("distal_overshoot")
    if int(probe.get("internalRiskViolationCount", 0) or 0) > 0:
        failures.append("internal_risk")
    if probe.get("entrySurfaceCrossingStatus") == "failed_post_entry_containment":
        failures.append("entry_surface")
    return failures


def enrich_result(server: Any, row: dict[str, Any], tolerance_mm: float) -> dict[str, Any]:
    audit = strict.independent_case_audit(server, row)
    violations = []
    for probe in row.get("selectedProbes") or []:
        probe["hardConstraintViolations"] = hard_violations(probe, tolerance_mm)
        violations.extend(probe["hardConstraintViolations"])
    required_units = int(row.get("requiredCoverageUnits", 0) or 0)
    covered_units = int(row.get("coveredCoverageUnits", 0) or 0)
    full = bool(
        row.get("status") == "ok"
        and required_units > 0
        and covered_units == required_units
        and not row.get("uncoveredTargets")
        and not row.get("uncoveredSides")
        and row.get("selectedProbes")
    )
    if full:
        coverage_status = "full"
    elif row.get("status") == "fail_closed" or (
        not row.get("selectedProbes") and covered_units < required_units
    ):
        coverage_status = "fail-closed"
    else:
        coverage_status = "partial"
    row["coverageStatus"] = coverage_status
    row["hardConstraintViolations"] = sorted(set(violations))
    row["hardConstraintViolationCount"] = len(violations)
    row["independentStrictAudit"] = audit
    row["strictAuditPassed"] = bool(
        coverage_status == "full"
        and audit.get("allProbesStrictPass")
        and audit.get("allReportedFieldsMatch")
        and not violations
    )
    return row


def failed_result(item: dict[str, Any], exc: Exception) -> dict[str, Any]:
    return {
        "caseId": item["caseId"],
        "caseType": item["category"],
        "requestedTargets": item["requestedTargets"],
        "targetingMode": item["targetingMode"],
        "expectFailClosed": item.get("expectFailClosed", False),
        "status": "error",
        "coverageStatus": "error",
        "error": f"{exc.__class__.__name__}: {exc}",
        "candidateCount": 0,
        "selectedProbeCount": 0,
        "uncoveredTargets": item["requestedTargets"],
        "selectedProbes": [],
        "strictAuditPassed": False,
        "runtimeSec": None,
    }


def build_contract(args: argparse.Namespace, lock: dict[str, Any]) -> dict[str, Any]:
    profile_manifest = PROFILE_ROOT / "artifact_manifest.json"
    actual_manifest_hash = sha256(MANIFEST_PATH)
    if lock.get("status") != "LOCKED_UNEXECUTED":
        raise RuntimeError(f"Unexpected holdout lock status: {lock.get('status')}")
    if actual_manifest_hash != lock.get("manifestSha256"):
        raise RuntimeError("Untouched holdout manifest does not match its pre-run lock")
    return {
        "schemaVersion": "probeplanner.v021_untouched_holdout.run_contract.v1",
        "interpretation": "first_execution_after_manifest_hash_lock",
        "lockedAt": lock["lockedAt"],
        "manifestSha256": actual_manifest_hash,
        "lockFileSha256": sha256(LOCK_PATH),
        "gitHead": git_value("rev-parse", "HEAD"),
        "gitDirty": bool(git_value("status", "--porcelain")),
        "sourceFiles": {
            str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path)
            for path in SOURCE_FILES
        },
        "profileRoot": str(PROFILE_ROOT.resolve()),
        "profileManifestSha256": sha256(profile_manifest),
        "workers": int(args.workers),
        "exactValidationInThisRun": False,
        "overshootToleranceMm": float(args.overshoot_tolerance_mm),
    }


def write_csvs(cases: list[dict[str, Any]]) -> None:
    fields = [
        "caseId", "caseType", "requestedTargets", "targetingMode", "expectFailClosed",
        "candidateCount", "selectedProbeCount", "coverageStatus", "strictAuditPassed",
        "hardConstraintViolationCount", "uncoveredTargets", "runtimeSec",
    ]
    with CASE_CSV_PATH.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in cases:
            out = {key: row.get(key) for key in fields}
            out["requestedTargets"] = json.dumps(row.get("requestedTargets") or [])
            out["uncoveredTargets"] = json.dumps(row.get("uncoveredTargets") or [])
            writer.writerow(out)
    probe_fields = [
        "caseId", "probeIndex", "entryCcfUm", "tipCcfUm", "entryPlannerMm", "tipPlannerMm",
        "depthUm", "thetaDeg", "phiDeg", "brainContainmentPassed", "tipInTarget",
        "distalOvershootMm", "hardConstraintViolations",
    ]
    with PROBE_CSV_PATH.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=probe_fields)
        writer.writeheader()
        for row in cases:
            for probe in row.get("selectedProbes") or []:
                out = {"caseId": row["caseId"]}
                for key in probe_fields[1:]:
                    value = probe.get(key)
                    out[key] = json.dumps(value) if isinstance(value, (list, dict)) else value
                writer.writerow(out)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--overshoot-tolerance-mm", type=float, default=0.025)
    parser.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    started = time.perf_counter()
    run_started_at = datetime.now(timezone.utc).isoformat()
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    contract = build_contract(args, lock)
    contract_hash = stable_hash(contract)
    save(CONTRACT_PATH, {**contract, "contractSha256": contract_hash})

    results_by_case: dict[str, dict[str, Any]] = {}
    if args.resume and CHECKPOINT_PATH.exists():
        checkpoint = json.loads(CHECKPOINT_PATH.read_text(encoding="utf-8"))
        if checkpoint.get("contractSha256") != contract_hash:
            raise RuntimeError("Checkpoint contract mismatch; preserve it and rerun with --no-resume")
        results_by_case = {
            str(row["caseId"]): row
            for row in checkpoint.get("cases", [])
            if isinstance(row, dict) and row.get("coverageStatus") != "error"
        }

    atlas_util.configure_backend_environment(PROFILE_ROOT, workers=int(args.workers))
    server = atlas_util.import_backend_server()
    server.load_atlas()
    if not server.atlas_loaded:
        raise RuntimeError(f"Atlas failed to load: {server.atlas_error}")
    targets = sorted({target for row in manifest["cases"] for target in row["requestedTargets"]})
    ontology = atlas_util.apply_structure_tree_descendant_fallback(
        server, targets, atlas_util.DEFAULT_STRUCTURES_JSON
    )

    with server.app.app_context():
        for index, item in enumerate(manifest["cases"], start=1):
            case_id = str(item["caseId"])
            if case_id in results_by_case:
                print(f"[untouched {index}/{len(manifest['cases'])}] {case_id} resume-skip", flush=True)
                continue
            print(f"[untouched {index}/{len(manifest['cases'])}] {case_id} {item['requestedTargets']}", flush=True)
            try:
                result = bench.run_case(
                    server, benchmark_case(item), int(args.workers), exact_validate=False
                )
                result["expectFailClosed"] = bool(item.get("expectFailClosed", False))
                result = enrich_result(server, result, float(args.overshoot_tolerance_mm))
            except Exception as exc:
                result = failed_result(item, exc)
            results_by_case[case_id] = result
            ordered = [
                results_by_case[row["caseId"]]
                for row in manifest["cases"]
                if row["caseId"] in results_by_case
            ]
            save(
                CHECKPOINT_PATH,
                {
                    "schemaVersion": "probeplanner.v021_untouched_holdout.checkpoint.v1",
                    "contractSha256": contract_hash,
                    "completedCaseCount": len(ordered),
                    "cases": ordered,
                },
            )

    if stable_hash(build_contract(args, lock)) != contract_hash:
        raise RuntimeError("Source, lock, manifest, or profile contract changed during execution")
    cases = [results_by_case[row["caseId"]] for row in manifest["cases"]]
    statuses = Counter(str(row.get("coverageStatus")) for row in cases)
    runtimes = [float(row["runtimeSec"]) for row in cases if row.get("runtimeSec") is not None]
    expected_full_failures = [
        row["caseId"] for row in cases
        if not row.get("expectFailClosed") and row.get("coverageStatus") != "full"
    ]
    negative_control_failures = [
        row["caseId"] for row in cases
        if row.get("expectFailClosed") and row.get("coverageStatus") != "fail-closed"
    ]
    strict_failures = [
        row["caseId"] for row in cases
        if row.get("coverageStatus") == "full" and not row.get("strictAuditPassed")
    ]
    error_cases = [row["caseId"] for row in cases if row.get("coverageStatus") == "error"]
    gate_failures = []
    if len(cases) != int(manifest["caseCount"]):
        gate_failures.append("case_count_mismatch")
    if expected_full_failures:
        gate_failures.append("prespecified_positive_case_not_full")
    if negative_control_failures:
        gate_failures.append("negative_control_did_not_fail_closed")
    if strict_failures:
        gate_failures.append("strict_audit_failure_in_full_case")
    if error_cases:
        gate_failures.append("execution_error")
    summary = {
        "totalCases": len(cases),
        "fullCoverageCount": statuses["full"],
        "partialCoverageCount": statuses["partial"],
        "failClosedCount": statuses["fail-closed"],
        "errorCount": statuses["error"],
        "strictAuditPassCount": sum(1 for row in cases if row.get("strictAuditPassed")),
        "expectedFullFailures": expected_full_failures,
        "negativeControlFailures": negative_control_failures,
        "strictFullCoverageFailures": strict_failures,
        "runtimeSec": {
            "median": statistics.median(runtimes) if runtimes else None,
            "p95": percentile(runtimes, 0.95),
            "max": max(runtimes) if runtimes else None,
            "totalWall": time.perf_counter() - started,
        },
        "acceptanceGate": "PASS" if not gate_failures else "FAIL",
        "gateFailures": gate_failures,
    }
    payload = {
        "schemaVersion": "probeplanner.v021_untouched_holdout.results.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "runStartedAt": run_started_at,
        "lockedAt": lock["lockedAt"],
        "interpretation": contract["interpretation"],
        "contractSha256": contract_hash,
        "contract": contract,
        "ontologyFallback": deepcopy(ontology),
        "summary": summary,
        "cases": cases,
    }
    save(RESULTS_PATH, payload)
    save(SUMMARY_PATH, summary)
    write_csvs(cases)
    REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 untouched holdout",
                "",
                f"- Manifest locked at: `{lock['lockedAt']}`",
                f"- Run started at: `{run_started_at}`",
                f"- Manifest SHA-256: `{lock['manifestSha256']}`",
                f"- Cases: {summary['totalCases']}",
                f"- Full / partial / fail-closed / error: {summary['fullCoverageCount']} / {summary['partialCoverageCount']} / {summary['failClosedCount']} / {summary['errorCount']}",
                f"- Strict full-case failures: {', '.join(strict_failures) if strict_failures else 'none'}",
                f"- Acceptance gate: **{summary['acceptanceGate']}**",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    return 0 if not gate_failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
