#!/usr/bin/env python3
"""Run historical regression with the targeted-mirror final source."""

from pathlib import Path

import run_historical_regression as runner


HERE = Path(__file__).resolve().parent
runner.CONTRACT_PATH = HERE / "targeted_mirror_source_historical_regression_contract.json"
runner.CHECKPOINT_PATH = HERE / "targeted_mirror_source_historical_regression_checkpoint.json"
runner.RESULTS_PATH = HERE / "targeted_mirror_source_historical_regression_results.json"
runner.SUMMARY_PATH = HERE / "targeted_mirror_source_historical_regression_summary.json"
runner.CASE_CSV_PATH = HERE / "targeted_mirror_source_historical_regression_cases.csv"
runner.PROBE_CSV_PATH = HERE / "targeted_mirror_source_historical_regression_probes.csv"
runner.REPORT_PATH = HERE / "TARGETED_MIRROR_SOURCE_HISTORICAL_REGRESSION_REPORT.md"
runner.SOURCE_FILES = (Path(__file__).resolve(), *runner.SOURCE_FILES)


if __name__ == "__main__":
    raise SystemExit(runner.main())
