#!/usr/bin/env python3
"""Run the independent exact oracle for every full v5 holdout case."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

import run_v021_v4_exact_oracle as base


HERE = Path(__file__).resolve().parent
base.MANIFEST_PATH = HERE / "v021_v5_final_holdout_manifest.json"
base.LOCK_PATH = HERE / "v021_v5_final_holdout_lock.json"
base.HOLDOUT_RESULTS_PATH = HERE / "v021_v5_final_holdout_results.json"
base.runner.CONTRACT_PATH = HERE / "v021_v5_exact_oracle_contract.json"
base.runner.CHECKPOINT_PATH = HERE / "v021_v5_exact_oracle_checkpoint.json"
base.runner.RESULTS_PATH = HERE / "v021_v5_exact_oracle_results.json"
base.runner.SUMMARY_PATH = HERE / "v021_v5_exact_oracle_summary.json"
base.runner.CSV_PATH = HERE / "v021_v5_exact_oracle_cases.csv"
base.runner.REPORT_PATH = HERE / "V021_V5_EXACT_ORACLE_REPORT.md"
base.runner.MODEL_DIR = HERE / "v021_v5_exact_models"
base.runner.SOURCE_FILES = (Path(__file__).resolve(), *base.runner.SOURCE_FILES)
_base_build_contract = base.build_contract


def build_contract(args: Any) -> dict[str, Any]:
    payload = _base_build_contract(args)
    payload["schemaVersion"] = "probeplanner.v021_v5_exact_oracle.contract.v1"
    payload["interpretation"] = "post_run_exact_oracle_for_all_full_prespecified_v5_holdout_cases"
    return payload


def load_cases() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    holdout = json.loads(base.HOLDOUT_RESULTS_PATH.read_text(encoding="utf-8"))
    rows = []
    for source in holdout["cases"]:
        if source.get("coverageStatus") != "full":
            continue
        count = int(source["selectedProbeCount"])
        rows.append(
            {
                "cohort": "v5_untouched_full",
                "caseId": str(source["caseId"]),
                "requestedTargets": list(source["requestedTargets"]),
                "targetingMode": str(source["targetingMode"]),
                "plannerRequest": deepcopy(source["plannerRequest"]),
                "historicalPlannerCount": count,
                "historicalExactMinimumCount": count,
                "historicalExactMatch": True,
                "regressionPlannerCount": count,
            }
        )
    if len(rows) != int(holdout["summary"]["fullCoverageCount"]):
        raise RuntimeError("Full-case roster does not match the frozen v5 first-run summary")
    return rows, {}


def main() -> int:
    base.build_contract = build_contract
    base.load_cases = load_cases
    code = base.main()
    summary = json.loads(base.runner.SUMMARY_PATH.read_text(encoding="utf-8"))
    base.runner.REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 v5 exact candidate-pool oracle",
                "",
                "This audit covers every full case from the prespecified v5 first execution.",
                "",
                f"- Proven optimal: {summary['exactCertifiedCaseCount']}/{summary['totalCaseCount']}",
                f"- ProbePlanner exact matches: {summary['probePlannerExactMatchCount']}/{summary['totalCaseCount']}",
                f"- Timeouts: {summary['timeoutCount']}",
                f"- Acceptance gate: **{summary['acceptanceGate']}**",
                "",
                "Certificates apply to regenerated strictly filtered candidate pools, not the continuous trajectory space.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    return code


if __name__ == "__main__":
    raise SystemExit(main())
