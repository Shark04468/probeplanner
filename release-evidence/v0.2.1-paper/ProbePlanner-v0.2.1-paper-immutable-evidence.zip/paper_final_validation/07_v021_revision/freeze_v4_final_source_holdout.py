#!/usr/bin/env python3
"""Freeze the final-source v4 untouched holdout before any planner execution."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import freeze_new_untouched_holdout as base


HERE = Path(__file__).resolve().parent
MANIFEST_PATH = HERE / "v021_v4_final_source_holdout_manifest.json"
LOCK_PATH = HERE / "v021_v4_final_source_holdout_lock.json"
SHA_PATH = HERE / "v021_v4_final_source_holdout_manifest.sha256"
V3_LOCK_PATH = HERE / "v021_v3_untouched_holdout_lock.json"
TEST_FILE = base.ROOT / "apps" / "backend-compat" / "tests" / "test_validation_scripts.py"


# Anatomically stratified and fixed without invoking candidate generation or planning.
CASES = [
    base.case("v021_v4_001_single_rspv", "single", ["RSPv"]),
    base.case("v021_v4_002_single_visam", "single", ["VISam"]),
    base.case("v021_v4_003_single_gpe", "single", ["GPe"]),
    base.case("v021_v4_004_single_ad", "single", ["AD"]),
    base.case("v021_v4_005_single_bst", "single", ["BST"]),
    base.case("v021_v4_006_single_mob", "single", ["MOB"]),
    base.case("v021_v4_007_nearby_anterior_thalamic", "nearby_multi", ["AD", "AV", "AM"]),
    base.case("v021_v4_008_nearby_pallidal", "nearby_multi", ["GPe", "GPi"]),
    base.case("v021_v4_009_nearby_olfactory_amygdala", "nearby_multi", ["COAa", "COAp", "NLOT"]),
    base.case("v021_v4_010_nearby_subiculum", "nearby_multi", ["PRE", "POST", "ProS"]),
    base.case("v021_v4_011_distributed_visl_ld", "distributed", ["VISl", "LD"]),
    base.case("v021_v4_012_distributed_audd_lgv", "distributed", ["AUDd", "LGv"]),
    base.case("v021_v4_013_distributed_mob_rt", "distributed", ["MOB", "RT"]),
    base.case("v021_v4_014_bilateral_rspv_ad", "bilateral", ["RSPv", "AD"], "bilateral_symmetric"),
    base.case("v021_v4_015_bilateral_gpe_lgv", "bilateral", ["GPe", "LGv"], "bilateral_symmetric"),
    base.case("v021_v4_016_bilateral_coaa_ld", "bilateral", ["COAa", "LD"], "bilateral_symmetric"),
    base.case("v021_v4_017_triad_visual_thalamic_bst", "high_order", ["VISam", "LD", "BST"]),
    base.case("v021_v4_018_quartet_distributed", "high_order", ["AUDd", "GPe", "AV", "SI"]),
    base.case("v021_v4_019_quintet_distributed", "high_order", ["RSPv", "VISl", "AD", "COAp", "GPi"]),
    base.case(
        "v021_v4_020_fail_closed_shallow_gpi",
        "negative_control",
        ["GPi"],
        depth_um=1200.0,
        max_angle_deg=5.0,
        expect_fail_closed=True,
    ),
]


def main() -> int:
    if MANIFEST_PATH.exists() or LOCK_PATH.exists() or SHA_PATH.exists():
        raise SystemExit("v4 holdout is already frozen; refusing to overwrite lock artifacts")
    region_map = json.loads(base.REGION_MAP.read_text(encoding="utf-8"))
    ids = {str(row["canonicalAcronym"]): int(row["id"]) for row in region_map["entries"]}
    case_ids = [row["caseId"] for row in CASES]
    if len(case_ids) != len(set(case_ids)):
        raise RuntimeError("Duplicate v4 holdout case ID")
    missing = sorted({target for row in CASES for target in row["requestedTargets"] if target not in ids})
    if missing:
        raise RuntimeError(f"Targets missing from bound region map: {missing}")

    v3_lock = json.loads(V3_LOCK_PATH.read_text(encoding="utf-8"))
    frozen_at = datetime.now(timezone.utc).isoformat()
    manifest = {
        "schemaVersion": "probeplanner.prespecified_untouched_holdout.v4",
        "createdAt": frozen_at,
        "label": "v0.2.1 final-source prespecified untouched holdout benchmark",
        "outcomeState": "unobserved_at_lock",
        "supersedesManifestSha256": v3_lock["manifestSha256"],
        "supersessionReason": (
            "v3 exposed bilateral coverage and target-depth candidate defects; v4 binds the final "
            "remediated source and a new fixed case roster before execution"
        ),
        "caseSelection": (
            "anatomically stratified fixed roster selected from the bound ontology without invoking "
            "candidate generation, scoring, optimization, or result preflight"
        ),
        "methodSnapshot": {
            "gitHead": base.git_value("rev-parse", "HEAD"),
            "gitDirty": bool(base.git_value("status", "--porcelain")),
            "sourceFiles": {
                str(path.relative_to(base.ROOT)).replace("\\", "/"): base.sha256(path)
                for path in (*base.SOURCE_FILES, TEST_FILE)
            },
        },
        "verificationBeforeLock": {
            "backendTestCommand": "python -m pytest apps/backend-compat/tests -q",
            "backendTestResult": "109 passed",
            "historicalRegressionResult": "24 positive full and 2 negative controls fail-closed",
            "historicalExactOracleStateAtSelection": "running; no v4 cases executed",
        },
        "profileRoot": str(base.PROFILE_ROOT.resolve()),
        "profileManifestSha256": base.sha256(base.PROFILE_MANIFEST),
        "regionMapV2Sha256": base.sha256(base.REGION_MAP),
        "plannerInvokedDuringSelection": False,
        "candidateOutcomesObservedDuringSelection": False,
        "caseCount": len(CASES),
        "acceptanceGates": {
            "allCasesRetained": True,
            "noExecutionErrors": True,
            "fullCasesRequireIndependentStrictAudit": True,
            "negativeControlsMustFailClosed": True,
            "exactOracleRequiredForAllFullCases": True,
            "noOracleTimeouts": True,
        },
        "cases": [
            {
                **row,
                "targetStructureIds": [ids[target] for target in row["requestedTargets"]],
            }
            for row in CASES
        ],
    }
    base.save(MANIFEST_PATH, manifest)
    manifest_hash = base.sha256(MANIFEST_PATH)
    lock = {
        "schemaVersion": "probeplanner.untouched_holdout.lock.v1",
        "lockedAt": frozen_at,
        "status": "LOCKED_UNEXECUTED",
        "manifestPath": str(MANIFEST_PATH.resolve()),
        "manifestSha256": manifest_hash,
        "generatorPath": str(Path(__file__).resolve()),
        "generatorSha256": base.sha256(Path(__file__).resolve()),
        "outcomesObservedBeforeLock": False,
        "unlockPolicy": "never overwrite; create a new versioned manifest if the protocol changes",
    }
    base.save(LOCK_PATH, lock)
    SHA_PATH.write_text(f"{manifest_hash}  {MANIFEST_PATH.name}\n", encoding="ascii")
    print(json.dumps(lock, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
