#!/usr/bin/env python3
"""Re-audit the fixed historical 48-case cohort with the v0.2.1 candidate pool."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import subprocess
import sys
import time
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SCRIPT_DIR = ROOT / "apps" / "backend-compat" / "scripts"
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import audit_registration_perturbation_sensitivity as atlas_util  # noqa: E402


PROFILE_ROOT = Path(r"D:\mri_ccf\planner_artifacts\ambmc_true_outer_full")
LOCKED_MANIFEST = Path(
    r"C:\Users\CHIXIA\Desktop\probe2.0\ProbePlanner_priority_1-4_6_results_2026-07-11"
    r"\01-03_strict_planning\final-benchmark-manifest.json"
)
REGRESSION_RESULTS = HERE / "historical_regression_results.json"
OLD_ORACLE_DIR = HERE.parent / "03_exact_probe_count_oracle"
OLD_ORACLE_RESULTS = OLD_ORACLE_DIR / "exact_oracle_results.json"
OLD_ORACLE_RUNNER = OLD_ORACLE_DIR / "run_exact_oracle.py"
CONTRACT_PATH = HERE / "v021_exact_oracle_contract.json"
CHECKPOINT_PATH = HERE / "v021_exact_oracle_checkpoint.json"
RESULTS_PATH = HERE / "v021_exact_oracle_results.json"
SUMMARY_PATH = HERE / "v021_exact_oracle_summary.json"
CSV_PATH = HERE / "v021_exact_oracle_cases.csv"
REPORT_PATH = HERE / "V021_EXACT_ORACLE_REPORT.md"
MODEL_DIR = HERE / "v021_exact_models"
SOURCE_FILES = (
    Path(__file__).resolve(),
    ROOT / "apps" / "backend-compat" / "src" / "optimizer_server.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "audit_registration_perturbation_sensitivity.py",
    ROOT / "apps" / "backend-compat" / "scripts" / "benchmark_auto_probe_count_planning.py",
    OLD_ORACLE_RUNNER,
)


def load_oracle_module() -> Any:
    spec = importlib.util.spec_from_file_location("probeplanner_locked_exact_oracle", OLD_ORACLE_RUNNER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import exact oracle implementation: {OLD_ORACLE_RUNNER}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


oracle = load_oracle_module()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_hash(payload: Any) -> str:
    blob = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def save(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def git_value(*args: str) -> str:
    return subprocess.check_output(
        ["git", "-C", str(ROOT), *args], text=True, encoding="utf-8"
    ).strip()


def build_contract(args: argparse.Namespace) -> dict[str, Any]:
    profile_manifest = PROFILE_ROOT / "artifact_manifest.json"
    return {
        "schemaVersion": "probeplanner.v021_exact_oracle.contract.v1",
        "interpretation": "post_hoc_fixed_historical_48_case_candidate_pool_oracle",
        "gitHead": git_value("rev-parse", "HEAD"),
        "gitDirty": bool(git_value("status", "--porcelain")),
        "sourceFiles": {
            str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path)
            for path in SOURCE_FILES
        },
        "lockedManifest": str(LOCKED_MANIFEST.resolve()),
        "lockedManifestSha256": sha256(LOCKED_MANIFEST),
        "historicalRegressionResultsSha256": sha256(REGRESSION_RESULTS),
        "oldOracleResultsSha256": sha256(OLD_ORACLE_RESULTS),
        "profileRoot": str(PROFILE_ROOT.resolve()),
        "profileManifestSha256": sha256(profile_manifest),
        "solver": "SciPy milp / HiGHS binary MILP",
        "solverTimeLimitSecPerCase": float(args.solver_time_limit_sec),
        "mipRelativeGap": 0.0,
        "workers": int(args.workers),
        "requestWorkerOverrideKeys": [
            "computeWorkers", "candidateGenWorkers", "prefilterWorkers"
        ],
        "fixedCohortCaseCount": 48,
        "claimScope": "minimum-cardinality feasible set within each regenerated strictly filtered candidate pool",
    }


def load_cases() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    locked = json.loads(LOCKED_MANIFEST.read_text(encoding="utf-8"))
    regression = json.loads(REGRESSION_RESULTS.read_text(encoding="utf-8"))
    previous = json.loads(OLD_ORACLE_RESULTS.read_text(encoding="utf-8"))
    locked_by_id = {str(row["caseId"]): row for row in locked["cases"]}
    regression_by_id = {str(row["caseId"]): row for row in regression["cases"]}
    previous_by_id = {str(row["caseId"]): row for row in previous["cases"]}
    rows = []
    for prior in previous["cases"]:
        case_id = str(prior["caseId"])
        cohort = str(prior["cohort"])
        source = locked_by_id[case_id] if cohort == "locked27" else regression_by_id[case_id]
        rows.append(
            {
                "cohort": cohort,
                "caseId": case_id,
                "requestedTargets": list(source["requestedTargets"]),
                "targetingMode": str(source["targetingMode"]),
                "plannerRequest": deepcopy(source["plannerRequest"]),
                "historicalPlannerCount": int(prior["probePlannerSelectedCount"]),
                "historicalExactMinimumCount": int(prior["exactOracleMinimumCount"]),
                "historicalExactMatch": bool(prior["exactMatchRerun"]),
                "regressionPlannerCount": (
                    int(source["selectedProbeCount"])
                    if cohort != "locked27" and source.get("selectedProbeCount") is not None
                    else None
                ),
            }
        )
    if len(rows) != 48 or len({row["caseId"] for row in rows}) != 48:
        raise RuntimeError("The frozen historical exact-oracle cohort is not 48 unique cases")
    return rows, previous_by_id


def failed_row(item: dict[str, Any], exc: Exception, runtime_sec: float) -> dict[str, Any]:
    return {
        **{key: item[key] for key in (
            "cohort", "caseId", "requestedTargets", "targetingMode",
            "historicalPlannerCount", "historicalExactMinimumCount", "historicalExactMatch",
            "regressionPlannerCount",
        )},
        "candidatePoolSize": 0,
        "pipelineCandidatePoolSize": 0,
        "conflictCount": 0,
        "probePlannerSelectedCount": 0,
        "exactOracleMinimumCount": None,
        "exactMatchRerun": False,
        "exactMinimumMatchesHistorical": False,
        "replayCountMatchesHistorical": False,
        "replayCountMatchesRegression": None,
        "solverStatus": "error",
        "solverMessage": f"{exc.__class__.__name__}: {exc}",
        "solverRuntimeSec": 0.0,
        "pipelineRuntimeSec": None,
        "optimalityGap": None,
        "timeout": False,
        "caseRuntimeSec": runtime_sec,
    }


def summarize(rows: list[dict[str, Any]], old_summary: dict[str, Any]) -> dict[str, Any]:
    certified = [row for row in rows if row["solverStatus"] == "proven_optimal"]
    exact_matches = sum(1 for row in certified if row["exactMatchRerun"])
    old_exact_matches = int(old_summary["probePlannerExactMatchCount"])
    failures = []
    if len(rows) != 48:
        failures.append("fixed_cohort_case_count_mismatch")
    if len(certified) != 48:
        failures.append("not_all_cases_proven_optimal")
    if exact_matches < old_exact_matches:
        failures.append("planner_exact_match_count_regressed")
    if any(row["solverStatus"] in {"error", "infeasible"} for row in rows):
        failures.append("oracle_error_or_infeasible")
    if any(row["timeout"] for row in rows):
        failures.append("oracle_timeout")
    return {
        "totalCaseCount": len(rows),
        "exactCertifiedCaseCount": len(certified),
        "probePlannerExactMatchCount": exact_matches,
        "probePlannerExactMatchRateAmongCertified": exact_matches / max(1, len(certified)),
        "historicalProbePlannerExactMatchCount": old_exact_matches,
        "exactMinimumUnchangedCount": sum(
            1 for row in certified if row["exactMinimumMatchesHistorical"]
        ),
        "plannerCountChangedCount": sum(
            1 for row in rows if not row["replayCountMatchesHistorical"]
        ),
        "solverStatusCounts": dict(Counter(str(row["solverStatus"]) for row in rows)),
        "timeoutCount": sum(1 for row in rows if row["timeout"]),
        "acceptanceGate": "PASS" if not failures else "FAIL",
        "gateFailures": failures,
    }


def write_csv(rows: list[dict[str, Any]]) -> None:
    fields = [
        "cohort", "caseId", "requestedTargets", "targetingMode", "candidatePoolSize",
        "historicalPlannerCount", "probePlannerSelectedCount", "historicalExactMinimumCount",
        "exactOracleMinimumCount", "exactMatchRerun", "exactMinimumMatchesHistorical",
        "replayCountMatchesHistorical", "solverStatus", "solverRuntimeSec", "pipelineRuntimeSec",
        "optimalityGap", "timeout", "conflictCount", "modelSha256",
    ]
    with CSV_PATH.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            out = {key: row.get(key) for key in fields}
            out["requestedTargets"] = json.dumps(row.get("requestedTargets") or [])
            writer.writerow(out)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--solver-time-limit-sec", type=float, default=120.0)
    parser.add_argument("--resume", action=argparse.BooleanOptionalAction, default=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    started = time.perf_counter()
    contract = build_contract(args)
    contract_hash = stable_hash(contract)
    save(CONTRACT_PATH, {**contract, "contractSha256": contract_hash})
    cases, _previous_by_id = load_cases()
    previous_payload = json.loads(OLD_ORACLE_RESULTS.read_text(encoding="utf-8"))

    results_by_case: dict[str, dict[str, Any]] = {}
    if args.resume and CHECKPOINT_PATH.exists():
        checkpoint = json.loads(CHECKPOINT_PATH.read_text(encoding="utf-8"))
        if checkpoint.get("contractSha256") != contract_hash:
            raise RuntimeError("Checkpoint contract mismatch; preserve it and rerun with --no-resume")
        results_by_case = {
            str(row["caseId"]): row
            for row in checkpoint.get("cases", [])
            if isinstance(row, dict) and row.get("solverStatus") != "error"
        }

    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    oracle.CONFIG = {
        "solverTimeLimitSecPerCase": float(args.solver_time_limit_sec),
        "mipRelativeGap": 0.0,
    }
    oracle.HERE = HERE
    oracle.MODEL_DIR = MODEL_DIR
    atlas_util.configure_backend_environment(PROFILE_ROOT, workers=int(args.workers))
    server = atlas_util.import_backend_server()
    server.load_atlas()
    if not server.atlas_loaded:
        raise RuntimeError(f"Atlas failed to load: {server.atlas_error}")
    targets = sorted({target for row in cases for target in row["requestedTargets"]})
    ontology = atlas_util.apply_structure_tree_descendant_fallback(
        server, targets, atlas_util.DEFAULT_STRUCTURES_JSON
    )

    with server.app.app_context():
        for index, item in enumerate(cases, start=1):
            case_id = item["caseId"]
            if case_id in results_by_case:
                print(f"[v0.2.1 oracle {index}/{len(cases)}] {case_id} resume-skip", flush=True)
                continue
            print(f"[v0.2.1 oracle {index}/{len(cases)}] {item['cohort']} {case_id}", flush=True)
            case_started = time.perf_counter()
            try:
                planner_request = deepcopy(item["plannerRequest"])
                request_params = planner_request.setdefault("params", {})
                for worker_key in contract["requestWorkerOverrideKeys"]:
                    request_params[worker_key] = int(args.workers)
                pipeline_started = time.perf_counter()
                pipeline = server._run_optimize_pipeline(planner_request)
                pipeline_runtime = time.perf_counter() - pipeline_started
                candidates = list(pipeline.get("candidatePreview") or [])
                selected = list(pipeline.get("selected") or [])
                model = oracle.build_exact_model(server, candidates, planner_request)
                model_path, model_hash = oracle.model_export(case_id, model)
                solved = oracle.solve_model(model)
                rerun_count = len(selected)
                exact_minimum = solved["exactMinimumCount"]
                row = {
                    **{key: item[key] for key in (
                        "cohort", "caseId", "requestedTargets", "targetingMode",
                        "historicalPlannerCount", "historicalExactMinimumCount", "historicalExactMatch",
                        "regressionPlannerCount",
                    )},
                    "candidatePoolSize": model["candidateCount"],
                    "pipelineCandidatePoolSize": model["pipelineCandidateCount"],
                    "conflictCount": len(model["conflicts"]),
                    "probePlannerSelectedCount": rerun_count,
                    "exactOracleMinimumCount": exact_minimum,
                    "exactMatchRerun": solved["solverStatus"] == "proven_optimal" and exact_minimum == rerun_count,
                    "exactMinimumMatchesHistorical": solved["solverStatus"] == "proven_optimal" and exact_minimum == item["historicalExactMinimumCount"],
                    "replayCountMatchesHistorical": rerun_count == item["historicalPlannerCount"],
                    "replayCountMatchesRegression": (
                        None if item["regressionPlannerCount"] is None
                        else rerun_count == item["regressionPlannerCount"]
                    ),
                    "pipelineRuntimeSec": pipeline_runtime,
                    "modelPath": model_path,
                    "modelSha256": model_hash,
                    **solved,
                    "caseRuntimeSec": time.perf_counter() - case_started,
                }
            except Exception as exc:
                row = failed_row(item, exc, time.perf_counter() - case_started)
            results_by_case[case_id] = row
            ordered = [results_by_case[item["caseId"]] for item in cases if item["caseId"] in results_by_case]
            save(
                CHECKPOINT_PATH,
                {
                    "schemaVersion": "probeplanner.v021_exact_oracle.checkpoint.v1",
                    "contractSha256": contract_hash,
                    "completedCaseCount": len(ordered),
                    "totalCaseCount": len(cases),
                    "cases": ordered,
                },
            )

    if stable_hash(build_contract(args)) != contract_hash:
        raise RuntimeError("Source or input contract changed during execution")
    rows = [results_by_case[item["caseId"]] for item in cases]
    summary = summarize(rows, previous_payload["summary"])
    payload = {
        "schemaVersion": "probeplanner.v021_exact_candidate_pool_oracle.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "interpretation": contract["interpretation"],
        "contractSha256": contract_hash,
        "contract": contract,
        "ontologyFallback": deepcopy(ontology),
        "summary": summary,
        "cases": rows,
    }
    save(RESULTS_PATH, payload)
    save(SUMMARY_PATH, summary)
    write_csv(rows)
    REPORT_PATH.write_text(
        "\n".join(
            [
                "# v0.2.1 exact candidate-pool oracle",
                "",
                "This is a post-hoc audit on the fixed historical 48-case cohort.",
                "",
                f"- Contract SHA-256: `{contract_hash}`",
                f"- Proven optimal: {summary['exactCertifiedCaseCount']}/{summary['totalCaseCount']}",
                f"- Current exact matches: {summary['probePlannerExactMatchCount']}/{summary['exactCertifiedCaseCount']}",
                f"- Historical exact matches: {summary['historicalProbePlannerExactMatchCount']}/48",
                f"- Exact minima unchanged: {summary['exactMinimumUnchangedCount']}/48",
                f"- Acceptance gate: **{summary['acceptanceGate']}**",
                "",
                "The certificate is limited to each regenerated strictly filtered candidate pool; it is not a continuous-space global optimum certificate.",
                "",
            ]
        ),
        encoding="utf-8",
    )
    print(json.dumps(summary, indent=2))
    return 0 if summary["acceptanceGate"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
