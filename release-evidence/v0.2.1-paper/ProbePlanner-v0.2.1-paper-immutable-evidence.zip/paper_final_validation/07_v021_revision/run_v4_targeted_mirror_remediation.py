#!/usr/bin/env python3
"""Re-run v4 failures with targeted rather than full mirror closure."""

from pathlib import Path

import run_v4_failure_remediation as runner


HERE = Path(__file__).resolve().parent
runner.RESULTS_PATH = HERE / "v021_v4_targeted_mirror_remediation_results.json"
runner.REPORT_PATH = HERE / "V021_V4_TARGETED_MIRROR_REMEDIATION_REPORT.md"
runner.SOURCE_FILES = (Path(__file__).resolve(), *runner.SOURCE_FILES)


if __name__ == "__main__":
    raise SystemExit(runner.main())
