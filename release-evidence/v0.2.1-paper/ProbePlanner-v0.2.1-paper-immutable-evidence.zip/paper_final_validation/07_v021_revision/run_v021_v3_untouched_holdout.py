#!/usr/bin/env python3
"""Run the locked v3 untouched holdout with the shared strict runner."""

from pathlib import Path

import run_v021_untouched_holdout as runner


HERE = Path(__file__).resolve().parent
runner.MANIFEST_PATH = HERE / "v021_v3_untouched_holdout_manifest.json"
runner.LOCK_PATH = HERE / "v021_v3_untouched_holdout_lock.json"
runner.CONTRACT_PATH = HERE / "v021_v3_untouched_holdout_run_contract.json"
runner.CHECKPOINT_PATH = HERE / "v021_v3_untouched_holdout_checkpoint.json"
runner.RESULTS_PATH = HERE / "v021_v3_untouched_holdout_results.json"
runner.SUMMARY_PATH = HERE / "v021_v3_untouched_holdout_summary.json"
runner.CASE_CSV_PATH = HERE / "v021_v3_untouched_holdout_cases.csv"
runner.PROBE_CSV_PATH = HERE / "v021_v3_untouched_holdout_probes.csv"
runner.REPORT_PATH = HERE / "V021_V3_UNTOUCHED_HOLDOUT_REPORT.md"
runner.SOURCE_FILES = (Path(__file__).resolve(), *runner.SOURCE_FILES)


if __name__ == "__main__":
    raise SystemExit(runner.main())
