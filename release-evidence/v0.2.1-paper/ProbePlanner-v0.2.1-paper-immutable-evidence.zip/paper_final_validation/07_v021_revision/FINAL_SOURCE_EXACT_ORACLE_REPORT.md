# v0.2.1 exact candidate-pool oracle

This is a post-hoc audit on the fixed historical 48-case cohort.

- Contract SHA-256: `ba062094ec31203e51c1db97d6c6961976acff081e66096d97887ad12b56d0a1`
- Proven optimal: 48/48
- Current exact matches: 48/48
- Historical exact matches: 47/48
- Exact minima unchanged: 43/48
- Acceptance gate: **PASS**

The certificate is limited to each regenerated strictly filtered candidate pool; it is not a continuous-space global optimum certificate.
