# v0.2.1 v5 exact candidate-pool oracle

This audit covers every full case from the prespecified v5 first execution.

- Proven optimal: 19/19
- ProbePlanner exact matches: 19/19
- Timeouts: 0
- Acceptance gate: **PASS**

Certificates apply to regenerated strictly filtered candidate pools, not the continuous trajectory space.
