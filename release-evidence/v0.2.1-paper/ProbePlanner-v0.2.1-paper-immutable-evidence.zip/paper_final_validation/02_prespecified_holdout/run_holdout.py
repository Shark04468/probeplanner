#!/usr/bin/env python3
"""Run the immutable untouched holdout against the exact paper release source."""

from __future__ import annotations

import csv
import hashlib
import json
import statistics
import subprocess
import sys
import time
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
CONFIG = json.loads((HERE / "CONFIG.json").read_text(encoding="utf-8"))
MANIFEST_PATH = HERE / "holdout_manifest.json"
CHECKPOINT_PATH = HERE / "holdout_checkpoint.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    pos = (len(ordered) - 1) * q
    low = int(pos)
    high = min(len(ordered) - 1, low + 1)
    weight = pos - low
    return float(ordered[low] * (1.0 - weight) + ordered[high] * weight)


def save(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def git_value(source: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(source), *args], text=True, encoding="utf-8").strip()


def import_release_modules(source: Path) -> tuple[Any, Any, Any]:
    script_dir = source / "apps" / "backend-compat" / "scripts"
    sys.path.insert(0, str(script_dir))
    import audit_registration_perturbation_sensitivity as atlas_util
    import benchmark_auto_probe_count_planning as bench
    import build_strict_final_benchmark as strict

    return atlas_util, bench, strict


def hard_violations(probe: dict[str, Any], tolerance_mm: float) -> list[str]:
    failures: list[str] = []
    if probe.get("brainContainmentPassed") is not True:
        failures.append("brain_containment")
    if probe.get("tipInTarget") is not True:
        failures.append("tip_in_target")
    overshoot = probe.get("distalOvershootMm")
    if overshoot is None or float(overshoot) > tolerance_mm + 1e-9:
        failures.append("distal_overshoot")
    if int(probe.get("internalRiskViolationCount", 0) or 0) > 0:
        failures.append("internal_risk")
    if probe.get("entrySurfaceCrossingStatus") == "failed_post_entry_containment":
        failures.append("entry_surface")
    return failures


def case_from_manifest(bench: Any, row: dict[str, Any]) -> Any:
    return bench.BenchmarkCase(
        case_id=str(row["caseId"]),
        case_type=str(row["category"]),
        purpose="Prespecified untouched holdout benchmark; fixed before planner execution.",
        requested_targets=tuple(str(value) for value in row["requestedTargets"]),
        targeting_mode=str(row["targetingMode"]),
        expected_probe_count=None,
        expect_fail_closed=bool(row.get("expectFailClosed", False)),
        depth_um=float(row.get("depthUm", 7600.0)),
        max_angle_deg=float(row.get("maxAngleDeg", 10.0)),
    )


def enrich_result(strict: Any, server: Any, row: dict[str, Any], tolerance_mm: float) -> dict[str, Any]:
    audit = strict.independent_case_audit(server, row)
    violations = []
    for probe in row.get("selectedProbes") or []:
        probe["hardConstraintViolations"] = hard_violations(probe, tolerance_mm)
        violations.extend(probe["hardConstraintViolations"])
    full = not row.get("uncoveredTargets") and not row.get("uncoveredSides") and bool(row.get("selectedProbes"))
    if full:
        coverage_status = "full"
    elif row.get("status") == "fail_closed" or (not row.get("selectedProbes") and row.get("uncoveredTargets")):
        coverage_status = "fail-closed"
    else:
        coverage_status = "partial"
    row["coverageStatus"] = coverage_status
    row["hardConstraintViolations"] = sorted(set(violations))
    row["hardConstraintViolationCount"] = len(violations)
    row["independentStrictAudit"] = audit
    row["strictAuditPassed"] = bool(
        coverage_status == "full"
        and audit.get("allProbesStrictPass")
        and audit.get("allReportedFieldsMatch")
        and not violations
    )
    return row


def write_case_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "caseId", "category", "requestedTargets", "targetingMode", "candidateCount",
        "selectedProbeCount", "coveredTargets", "uncoveredTargets", "coverageStatus",
        "strictAuditPassed", "hardConstraintViolationCount", "runtimeSec",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "caseId": row["caseId"],
                "category": row["caseType"],
                "requestedTargets": json.dumps(row.get("requestedTargets") or []),
                "targetingMode": row.get("targetingMode"),
                "candidateCount": row.get("candidateCount"),
                "selectedProbeCount": row.get("selectedProbeCount"),
                "coveredTargets": json.dumps(row.get("coveredTokens") or []),
                "uncoveredTargets": json.dumps(row.get("uncoveredTargets") or []),
                "coverageStatus": row.get("coverageStatus"),
                "strictAuditPassed": row.get("strictAuditPassed"),
                "hardConstraintViolationCount": row.get("hardConstraintViolationCount"),
                "runtimeSec": row.get("runtimeSec"),
            })


def write_probe_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = [
        "caseId", "probeIndex", "entryCcfUm", "tipCcfUm", "entryPlannerMm", "tipPlannerMm",
        "depthUm", "thetaDeg", "phiDeg", "brainContainmentPassed", "tipInTarget",
        "distalOvershootMm", "hardConstraintViolations",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            for probe in row.get("selectedProbes") or []:
                writer.writerow({
                    "caseId": row["caseId"],
                    **{key: json.dumps(probe.get(key)) if isinstance(probe.get(key), (list, dict)) else probe.get(key) for key in fields if key not in {"caseId", "hardConstraintViolations"}},
                    "hardConstraintViolations": json.dumps(probe.get("hardConstraintViolations") or []),
                })


def main() -> int:
    started = time.perf_counter()
    actual_hash = sha256(MANIFEST_PATH)
    expected_hash = str(CONFIG["manifestSha256"])
    if actual_hash != expected_hash:
        raise SystemExit(f"Holdout manifest hash mismatch: {actual_hash} != {expected_hash}")

    source = Path(CONFIG["methodSource"])
    commit = git_value(source, "rev-parse", "HEAD")
    dirty = git_value(source, "status", "--porcelain")
    if commit != CONFIG["methodReleaseCommit"] or dirty:
        raise SystemExit(f"Method source is not the clean locked release: commit={commit}, dirty={bool(dirty)}")

    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    atlas_util, bench, strict = import_release_modules(source)
    profile = Path(CONFIG["profileRoot"])
    workers = int(CONFIG["workers"])
    atlas_util.configure_backend_environment(profile, workers=workers)
    server = atlas_util.import_backend_server()
    server.load_atlas()
    if not server.atlas_loaded:
        raise RuntimeError(f"Atlas failed to load: {server.atlas_error}")
    all_targets = sorted({str(target) for row in manifest["cases"] for target in row["requestedTargets"]})
    ontology = atlas_util.apply_structure_tree_descendant_fallback(server, all_targets, atlas_util.DEFAULT_STRUCTURES_JSON)

    cases: list[dict[str, Any]] = []
    with server.app.app_context():
        for index, item in enumerate(manifest["cases"], start=1):
            print(f"[holdout {index}/{len(manifest['cases'])}] {item['caseId']} {item['requestedTargets']}", flush=True)
            case = case_from_manifest(bench, item)
            try:
                result = bench.run_case(server, case, workers, exact_validate=False)
                result = enrich_result(strict, server, result, float(CONFIG["overshootToleranceMm"]))
            except Exception as exc:
                result = {
                    "caseId": item["caseId"],
                    "caseType": item["category"],
                    "requestedTargets": item["requestedTargets"],
                    "targetingMode": item["targetingMode"],
                    "status": "error",
                    "coverageStatus": "fail-closed",
                    "error": f"{exc.__class__.__name__}: {exc}",
                    "candidateCount": 0,
                    "selectedProbeCount": 0,
                    "coveredTokens": [],
                    "uncoveredTargets": item["requestedTargets"],
                    "selectedProbes": [],
                    "strictAuditPassed": False,
                    "hardConstraintViolationCount": 0,
                    "runtimeSec": None,
                }
            cases.append(result)
            save(CHECKPOINT_PATH, {"manifestSha256": actual_hash, "completedCaseCount": len(cases), "cases": cases})

    status_counts = Counter(str(row["coverageStatus"]) for row in cases)
    runtimes = [float(row["runtimeSec"]) for row in cases if row.get("runtimeSec") is not None]
    probe_distribution = Counter(int(row.get("selectedProbeCount", 0) or 0) for row in cases)
    summary = {
        "totalCases": len(cases),
        "fullCoverageCount": status_counts["full"],
        "partialCoverageCount": status_counts["partial"],
        "failClosedCount": status_counts["fail-closed"],
        "fullCoverageRate": status_counts["full"] / len(cases),
        "partialCoverageRate": status_counts["partial"] / len(cases),
        "failClosedRate": status_counts["fail-closed"] / len(cases),
        "selectedProbeCountDistribution": {str(key): probe_distribution[key] for key in sorted(probe_distribution)},
        "strictAuditPassCount": sum(1 for row in cases if row.get("strictAuditPassed")),
        "strictAuditPassRateAllCases": sum(1 for row in cases if row.get("strictAuditPassed")) / len(cases),
        "strictAuditPassRateFullCoverage": (
            sum(1 for row in cases if row.get("coverageStatus") == "full" and row.get("strictAuditPassed")) / max(1, status_counts["full"])
        ),
        "runtimeSec": {
            "median": statistics.median(runtimes) if runtimes else None,
            "p95": percentile(runtimes, 0.95),
            "max": max(runtimes) if runtimes else None,
            "totalWall": time.perf_counter() - started,
        },
    }
    payload = {
        "schemaVersion": "probeplanner.prespecified_untouched_holdout.results.v1",
        "createdAt": datetime.now(timezone.utc).isoformat(),
        "label": manifest["label"],
        "manifestSha256": actual_hash,
        "methodReleaseCommit": commit,
        "methodSourceClean": not bool(dirty),
        "profileRoot": str(profile),
        "profileManifestSha256": sha256(profile / "artifact_manifest.json"),
        "seed": manifest["seed"],
        "ontologyFallback": deepcopy(ontology),
        "summary": summary,
        "cases": cases,
    }
    save(HERE / "holdout_results.json", payload)
    save(HERE / "holdout_summary.json", summary)
    write_case_csv(HERE / "holdout_case_results.csv", cases)
    write_probe_csv(HERE / "holdout_selected_probes.csv", cases)

    report = [
        "# Prespecified Untouched Holdout Benchmark",
        "",
        f"- Manifest SHA-256: `{actual_hash}`",
        f"- Method release commit: `{commit}`",
        f"- Total cases: {summary['totalCases']}",
        f"- Full / partial / fail-closed: {summary['fullCoverageCount']} / {summary['partialCoverageCount']} / {summary['failClosedCount']}",
        f"- Strict audit passes among full-coverage cases: {sum(1 for row in cases if row.get('coverageStatus') == 'full' and row.get('strictAuditPassed'))}/{summary['fullCoverageCount']}",
        f"- Runtime median / p95 / max: {summary['runtimeSec']['median']:.3f} / {summary['runtimeSec']['p95']:.3f} / {summary['runtimeSec']['max']:.3f} s",
        "",
        "All 26 prespecified cases are retained. No case was removed or rebalanced after planner execution.",
    ]
    (HERE / "REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

