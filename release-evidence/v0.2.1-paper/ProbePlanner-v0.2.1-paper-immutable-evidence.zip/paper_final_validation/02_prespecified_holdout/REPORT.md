# Prespecified Untouched Holdout Benchmark

- Manifest SHA-256: `25c177b405ecf395e86511e2150edef8bd7343a59e31497873b79705f39e5d55`
- Method release commit: `0d5748e05c05e54d1330d05009747bcb4fa915a5`
- Total cases: 26
- Full / partial / fail-closed: 21 / 3 / 2
- Strict audit passes among full-coverage cases: 21/21
- Runtime median / p95 / max: 25.863 / 65.799 / 76.556 s

All 26 prespecified cases are retained. No case was removed or rebalanced after planner execution.
